// IME composition lifecycle for the editor element.
//
// Split out because composition is not the brief, exceptional state the rest of
// the element assumes. Android keyboards hold one open continuously across
// ordinary typing, so anything a composition blocks is blocked permanently on a
// phone — and the commit below has to be callable mid-composition, not only at
// `compositionend`, so a projection-owned gesture can put the engine and the
// textarea back onto the same text before mapping offsets between them.

import { clearCompositionPresentation, renderCompositionPresentation } from "./composition_preview.js";
import { clearProjectionCompositionLine } from "./projection.js";
import { planDeferredHostReplace } from "./composition_defer.js";
import { reconcileTextareaMutation } from "./textarea_reconcile.js";

/** Paint the live composing line and its caret from the textarea. */
export function renderComposingPresentation(ctx) {
  renderCompositionPresentation(
    ctx.frame, ctx.projection, ctx.carets, ctx.input, ctx.composedRunLength(),
  );
}

/**
 * Fold the live composing run into the engine. Returns false when there was no
 * composition to commit, which is how `compositionend` knows to stop.
 */
export function commitComposition(ctx) {
  if (!ctx.isComposing() || !ctx.editor()) return false;
  ctx.setComposing(false);
  clearCompositionPresentation(ctx.frame);
  clearProjectionCompositionLine(ctx.projection);
  const change = reconcileTextareaMutation(ctx.editor(), ctx.input);
  // Textarea already holds the composed text; sync without re-applying edits
  // (which would double it).
  ctx.commitChange(change, "compositionCommit", null);
  return true;
}

/** Apply a host `replaceValue` that arrived while a composition was open. */
export function flushDeferredHostReplace(ctx) {
  const plan = planDeferredHostReplace(ctx.getDeferredReplace(), ctx.editor().snapshot());
  ctx.setDeferredReplace(null);
  if (!plan) return;
  ctx.commitChange(ctx.editor().replaceValue(plan.value, plan.revision), "hostReplacement");
}
