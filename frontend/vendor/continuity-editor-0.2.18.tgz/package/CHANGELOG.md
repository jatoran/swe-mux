# @continuity-editor/editor changelog

The embeddable SDK versions independently of the Continuity Windows desktop
application; `CHANGELOG.md` at the repository root is the desktop product's.
Release notes for `0.2.16` and earlier live in
[`EMBEDDING.md`](https://github.com/jatoran/continuity/blob/main/EMBEDDING.md),
which remains the cross-surface router.

## 0.2.18

### Fixed

- **Touch scrolling no longer focuses the editor or flashes the soft keyboard.**
  Touch `pointerdown` now records the gesture without focusing, capturing, or
  preventing the shield's native scroll. A resolved tap commits its measured
  projected caret and synchronously focuses the textarea in the trusted click
  turn; pan, cancellation, and long-press clicks stay unfocused. Mouse and pen
  focus/capture behavior is unchanged, and hosts need no shadow-root or
  caret-hit-test workaround.

### Notes

- No public API changes.

## 0.2.17

### Fixed

- **Thematic breaks render.** `---` projects to an empty display line — its
  dashes are a hidden marker — so it read as a blank line. It now draws a rule,
  suppressed on the caret's own line so the raw source comes back under the
  caret, the way heading sizing already behaved.
- **Tab-indented wrapped rows hang under their own content.** The hanging indent
  was expressed as `padding-inline-start` plus a negative `text-indent`. CSS
  anchors tab stops at the block's *content* edge, so the padding shifted the
  whole tab grid right by the indent while the negative indent pulled the first
  row left by it: a leading tab advanced to `indent mod tab-width` instead of to
  the first stop, and a nested bullet's own text rendered left of the rows
  hanging beneath it — by an amount that changed with the font's space advance,
  and never on a space-indented line. The indent is now
  `text-indent: <width> hanging`, which indents every row except the first
  without inline padding, so the grid origin stays under the first row. The
  padding form remains behind `@supports` for engines without the keyword.
- **Unrealized lines hang where they will hang once realized.** Lines outside
  the measured viewport window fell back to `ch` units with a hard-coded
  four-column tab. `ch` is the advance of `0`, which in a proportional font is
  neither the space advance nor the tab stop. They are now measured against the
  projection's own font metrics, read once per render pass.

### Added

- **`indent-guides="on"`** (property `indentGuides`, controller/React key
  `indentGuides`) paints vertical rules at each enclosing indent level. Off by
  default. Themed with `--continuity-indent-guide` and
  `--continuity-indent-guide-active`. Column semantics mirror the native
  desktop painter: a guide marks where an *enclosing* parent's content starts,
  the body-left-edge column is suppressed, a blank line inherits the columns its
  two non-blank neighbours share, and the caret's line draws its deepest column
  in the active colour.
- **`setDecorations(id, ranges)` / `clearDecorations(id?)`** paint named sets of
  source ranges without touching selection, history, or revision. This is what a
  host-side find bar needs: the projection realizes only the measured viewport,
  so offscreen matches are not in the DOM for a browser find, a host DOM walk, or
  CSS Highlights to reach. Each set is themed through
  `--continuity-decoration-<id>` (falling back to `--continuity-decoration`) and
  exposed as `part="decoration decoration-<id>"`. Ids must be CSS identifiers
  because they name both. Ranges are positions, not anchors: re-set them after a
  change.
- **Touch selection adjust handles.** The touch shield displaces the platform's
  own handles, so a selection was whatever the long-press produced and could not
  be nudged. Two handles now appear once the gesture settles and drag their edge
  through the same projected-glyph mapping the long-press drag uses, pivoting on
  the opposite edge frozen at grab time so a drag can cross the anchor. Coarse
  pointers only; `part="selection-handle selection-handle-start|-end"`.
- **`exportHistory(options?)` / `importHistory(history)`** move the undo tree
  across an unmount as plain JSON, for hosts that unmount the editor per tab or
  pane. The blob carries the content checksum and an import into different text
  is refused rather than replaying recorded inverse edits over the wrong bytes.
  `maxGroups` bounds it to the newest undo groups.

### Notes

- The installed-JavaScript budget moves 288 KiB -> 320 KiB for the above.
- No breaking changes. Every addition is additive in `index.d.ts`.
