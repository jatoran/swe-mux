/* tslint:disable */
/* eslint-disable */

/**
 * Internal WebAssembly editor handle wrapped by the npm TypeScript facade.
 *
 * **Thread ownership:** JavaScript owns this value on the constructing agent.
 * All mutation is synchronous; the handle creates no workers or callbacks.
 */
export class RawEditor {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Delete backward at every current selection.
     */
    delete_backward(timestamp_ms: number): string;
    /**
     * Delete forward at every current selection.
     */
    delete_forward(timestamp_ms: number): string;
    /**
     * Execute one storage-neutral command by its stable command identifier.
     */
    execute_command(command: string, timestamp_ms: number): string;
    /**
     * Construct an editor from host-owned text and revision state.
     */
    static fromSnapshot(initial_value: string, initial_revision: bigint): RawEditor;
    /**
     * Serialize the undo history, keeping only the newest `max_groups`
     * groups when that is non-zero.
     */
    history_json(max_groups: number): string;
    /**
     * Indent every selected line by the portable default tab unit.
     */
    indent(timestamp_ms: number): string;
    /**
     * Insert text at every current selection and return the change report JSON.
     */
    insert_text(text: string, timestamp_ms: number): string;
    /**
     * Current WebAssembly linear-memory allocation in bytes.
     */
    linear_memory_bytes(): number;
    /**
     * Construct an ephemeral editor with one buffer.
     */
    constructor(initial_value: string);
    /**
     * Outdent every selected line by the portable default tab unit.
     */
    outdent(timestamp_ms: number): string;
    /**
     * Compute the compact Markdown projection used by browser presentation.
     */
    presentation_json(): string;
    /**
     * Compute only a source-line range for an existing browser projection.
     */
    presentation_range_json(start_line: number, end_line: number): string;
    /**
     * Compute Markdown decoration and display projection synchronously.
     */
    projection_json(): string;
    /**
     * Reconcile the complete document only when `expected_revision` is current.
     */
    reconcile_text_if_revision(text: string, expected_revision: bigint, timestamp_ms: number): string;
    /**
     * Redo the most-recent child branch.
     */
    redo(timestamp_ms: number): string;
    /**
     * Redo the alternate child branch.
     */
    redo_alternate(timestamp_ms: number): string;
    /**
     * Adopt a serialized undo history captured from this same content.
     */
    restore_history_json(history_json: string): void;
    /**
     * Replace the current selections from a JSON array of portable selections.
     */
    set_selections_json(selections_json: string): void;
    /**
     * Return current text, revision, and normalized selections as JSON.
     */
    snapshot_json(): string;
    /**
     * Undo the current branch's latest group.
     */
    undo(timestamp_ms: number): string;
}

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_raweditor_free: (a: number, b: number) => void;
    readonly raweditor_delete_backward: (a: number, b: number, c: number) => void;
    readonly raweditor_delete_forward: (a: number, b: number, c: number) => void;
    readonly raweditor_execute_command: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly raweditor_fromSnapshot: (a: number, b: number, c: bigint) => number;
    readonly raweditor_history_json: (a: number, b: number, c: number) => void;
    readonly raweditor_indent: (a: number, b: number, c: number) => void;
    readonly raweditor_insert_text: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly raweditor_linear_memory_bytes: (a: number) => number;
    readonly raweditor_new: (a: number, b: number) => number;
    readonly raweditor_outdent: (a: number, b: number, c: number) => void;
    readonly raweditor_presentation_json: (a: number, b: number) => void;
    readonly raweditor_presentation_range_json: (a: number, b: number, c: number, d: number) => void;
    readonly raweditor_projection_json: (a: number, b: number) => void;
    readonly raweditor_reconcile_text_if_revision: (a: number, b: number, c: number, d: number, e: bigint, f: number) => void;
    readonly raweditor_redo: (a: number, b: number, c: number) => void;
    readonly raweditor_redo_alternate: (a: number, b: number, c: number) => void;
    readonly raweditor_restore_history_json: (a: number, b: number, c: number, d: number) => void;
    readonly raweditor_set_selections_json: (a: number, b: number, c: number, d: number) => void;
    readonly raweditor_snapshot_json: (a: number, b: number) => void;
    readonly raweditor_undo: (a: number, b: number, c: number) => void;
    readonly __wbindgen_export: (a: number) => void;
    readonly __wbindgen_add_to_stack_pointer: (a: number) => number;
    readonly __wbindgen_export2: (a: number, b: number, c: number) => void;
    readonly __wbindgen_export3: (a: number, b: number) => number;
    readonly __wbindgen_export4: (a: number, b: number, c: number, d: number) => number;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
