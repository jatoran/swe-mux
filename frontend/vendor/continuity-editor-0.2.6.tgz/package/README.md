# @continuity-editor/editor

Accessible `<continuity-editor>` Web Component and synchronous,
storage-neutral Continuity editor engine compiled to WebAssembly. The package
contains the component, TypeScript declarations, styles, source map, optimized
WASM, license, and per-file integrity metadata.

## Browser use

Importing the package defines the component. Initialize the shared WASM module,
set the initial value as a property, and wait for `ready` before reading state:

```js
import { initialize } from "@continuity-editor/editor";

await initialize();
const editor = document.querySelector("continuity-editor");
editor.value = "# Hello\n";
editor.initialRevision = savedRevision;
await editor.ready;

editor.addEventListener("continuity-change", async ({ detail }) => {
  if (detail.commitOrigin === "user") {
    await saveInYourHost(detail.sequence, detail.snapshot);
  }
});
```

```html
<continuity-editor aria-label="Project notes"></continuity-editor>
```

## Deploying

For Vite and compatible bundlers, import the exported WASM asset as a URL and
pass it explicitly. This is the canonical browser deployment path:

```js
import { initialize } from "@continuity-editor/editor";
import wasmUrl from "@continuity-editor/editor/wasm?url";

await initialize({ wasm: wasmUrl });
```

Serve `.wasm` as `Content-Type: application/wasm`; this is required by
`WebAssembly.instantiateStreaming`, and is mandatory when
`X-Content-Type-Options: nosniff` is enabled. Python's Windows MIME table may
not contain the mapping, so an aiohttp host can register it during startup:

```py
import mimetypes

mimetypes.add_type("application/wasm", ".wasm")
```

A strict Chromium Content Security Policy must allow WASM compilation. Add
`'wasm-unsafe-eval'` to `script-src` (or the effective `default-src`), for
example `script-src 'self' 'wasm-unsafe-eval'`. This does not enable general
JavaScript `eval`, and a same-origin bundled asset needs no additional
`connect-src` permission. See the [CSP specification](https://www.w3.org/TR/CSP3/#directive-script-src),
[MDN streaming compilation requirements](https://developer.mozilla.org/docs/WebAssembly/Reference/JavaScript_interface/instantiateStreaming_static),
and [Vite static asset imports](https://vite.dev/guide/assets.html).

## Framework-neutral controlled use

Vue, Svelte, Preact, and vanilla hosts can reuse the same controlled snapshot
semantics through `@continuity-editor/editor/controller`. Attach before the
element becomes ready, synchronize only complete engine snapshots, and dispose
the controller when the host view releases the element:

```js
import { attachContinuityEditor } from "@continuity-editor/editor/controller";

const element = document.createElement("continuity-editor");
const controller = attachContinuityEditor(element, {
  value: savedText,
  revision: savedEngineRevision,
  callbacks: {
    onChange: ({ snapshot }) => persistInHost(snapshot),
  },
});
mount.append(element);

await controller.synchronize(reloadedText, reloadedEngineRevision);
controller.dispose();
```

`synchronize()` uses revision-checked `replaceValue` and rejects with
`RevisionConflictError` rather than overwriting newer typing. `dispose()` only
detaches controller listeners; the host still owns the element. The React
adapter declaration is self-contained, so Preact consumers using
`preact/compat` do not need `@types/react` solely to import it.

Every change has `commitOrigin: "user" | "host"`. Persist only `"user"`;
`"host"` acknowledges a host replacement and must not loop back into storage.
`onHostReplacement` is the dedicated controller/React callback. The controller
also forwards selection, reveal, scroll-state, and linear-memory APIs.

Svelte hosts can use `/svelte`; Vue 3 hosts can use `/vue` (Vue is an optional
peer). `/lazy` dynamically loads route-local editors. `/conformance` exports a
disposable browser wiring harness, and `/commit-queue` provides an optional
single-in-flight, newest-wins debounced save queue with a maximum-delay cap.

## Plain text and static rendering

Set `syntax="plain"` to retain the rope, selection, undo, multi-cursor, and
host contracts while disabling Markdown projection. `<continuity-renderer>`
provides selectable, read-only Markdown or plain projection without an input
textarea.

## React use

The optional `@continuity-editor/editor/react` subpath supplies a controlled
React adapter without adding React to non-React consumers. Initialize WASM once
before mounting the application, then keep the complete Continuity snapshot in
React state:

```tsx
import { useState } from "react";
import { initialize } from "@continuity-editor/editor";
import { ContinuityEditor } from "@continuity-editor/editor/react";

await initialize();

export function NoteEditor({ initialText, persist }) {
  const [snapshot, setSnapshot] = useState({ text: initialText, revision: 0 });
  return (
    <ContinuityEditor
      aria-label="Project note"
      spellcheck={false}
      style={{ display: "block", width: "100%", height: "100%" }}
      value={snapshot.text}
      revision={snapshot.revision}
      onChange={(detail) => {
        setSnapshot(detail.snapshot);
        persist(detail.snapshot.text);
      }}
    />
  );
}
```

`revision` is the Continuity engine revision corresponding exactly to `value`.
It is not a database ETag, file mtime, or host optimistic-concurrency token.
Hosts keep those persistence revisions separately. Unchanged React props never
echo a replacement after local typing; a changed host snapshot is applied with
`replaceValue(value, revision)`, and stale replacement attempts call
`onRevisionConflict` instead of overwriting newer editor state. Use a stable
resource key and remount with revision zero when switching to a different note
unless the host persisted the previous Continuity revision.

The component uses a semantic `<textarea>` for input, IME, canonical selection,
clipboard, keyboard navigation, and accessibility. A DOM projection consumes
the shared Rust display map for Markdown presentation. Primary and secondary
carets and non-collapsed selection highlights are painted from that projection's
measured glyph rectangles, so wrapped rows cannot drift from raw-source
textarea geometry. Outside IME, both the native selection background and
foreground remain transparent so raw source cannot overpaint projected glyphs.
IME composition temporarily restores native glyph, caret,
and selection painting. While a composition is active the internal textarea is
never rewritten programmatically: host `value`/`replaceValue` writes and
controlled reconciliation defer until `compositionend`, then apply through the
revision guard so a stale echo cannot duplicate the just-composed word. This is
what keeps predictive mobile keyboards (Android GBoard, iOS Safari) from
re-injecting and compounding the document on the space key. The `composing`
property reports whether a composition is currently active. The semantic
textarea also disables `autocorrect` alongside `autocomplete` and
`autocapitalize` to reduce mobile composition churn. It never creates a
database or writes files: hosts decide whether changes are ephemeral or are
persisted after each ordered `continuity-change` event.

Public element APIs include `value`, `initialRevision`, `readOnly`,
`spellcheck`, `syntax`, `composing`, shortcut configuration, `snapshot()`,
`replaceValue()`, `executeCommand()`, `setSelections()`, `revealRange()`,
scroll capture/restore, `linearMemoryBytes()`, `focus()`, and `destroy()`.
Revision-checked replacement throws `RevisionConflictError` rather than
overwriting newer typing, and returns `null` when it defers because an IME
composition is active. Set `initialRevision` before readiness when restoring
host-managed state; the next edit advances from that revision. Host-owned link activation, context menus, and file
drops arrive as `continuity-request` events. All event payloads carry protocol
version `1`; mutating event streams also carry a monotonically increasing
sequence number.

Spellcheck follows the browser default. Set the standard `spellcheck` property
to `false`, use `<continuity-editor spellcheck="false">`, or pass
`spellcheck={false}` to the React adapter to disable it on the semantic
textarea. Changes apply immediately; shadow-root access is unnecessary.

Set `theme="light"` or `theme="dark"`, or override the inherited
`--continuity-*` custom properties. `--continuity-font-family` and
`--continuity-font-size` control the content font; `--continuity-line-height`
controls its line height. Tab indents selected lines through the
shared engine and Shift+Tab outdents them. Press Escape, then Tab or Shift+Tab,
to move focus out; the semantic input exposes this instruction to assistive
technology. Read-only editors release Tab directly. A form-like host may set
`tab-behavior="focus"` to make direct focus traversal the default.
Reduced-motion preferences disable component motion. Soft-wrap width changes
preserve the active caret row's screen y while browser typography is
remeasured. Typing, deletion, paste/cut/drop, indentation, composition commit,
undo, and redo reveal the active selection head when it crosses either viewport
edge and synchronize the visual projection in the same mutation turn. Host
`value`/`replaceValue` updates preserve the host-selected viewport.

The visual layer keeps canonical source text as full-document geometry and
realizes WYSIWYG projection for the measured pixel viewport plus two viewports
of overscan. Fast edits invalidate projection metadata only for touched lines:
active and structurally dirty lines reveal source immediately while untouched
lines retain their rendered Markdown during continuous typing. Line-count edits
splice source placeholders and aligned projection metadata in the fast frame,
so soft-wrapped content cannot translate the projection away from the revealed
caret. Ordinary character input does no idle parse work while its source line
remains active. When that line becomes inactive, the 250 ms reconciliation
requests only the measured source-line viewport from Rust. Structurally
significant edits retain a complete block reconciliation.

Shortcut policy defaults to `browser-safe`, which releases Chromium UI and
DevTools conflicts such as Ctrl/Cmd+E, K, R, Shift+R, J, Shift+J, U, and
Shift+C. Use `shortcut-policy="editor-first"` in a controlled Electron shell,
or `shortcut-policy="none"` when the host owns every command chord. Set
`shortcutBindings` to a record or map such as `{ "Mod+E":
"markdown.toggle_task", "Mod+R": null }`; explicit entries override the
selected policy. A browser may withhold browser-UI accelerators before the page
receives them, so hosts can call `executeCommand()` directly or mediate them in
Electron's main process. Native textarea motion remains intact: for example,
Ctrl+Shift+Left/Right extends by word.

The built-in non-browser-safe defaults are Mod+J, Mod+Shift+J, Mod+R,
Mod+Shift+R, Mod+U, Mod+Shift+S, Mod+E, Mod+Shift+C, and Mod+K. Call
`listShortcutBindings()` to inspect the complete binding table and its
`isBrowserSafe` flags. When a delivered built-in chord is released by policy,
the element emits `continuity-shortcut-suppressed` with `{ chord, command,
policy }`. To reclaim one known conflict without switching to `editor-first`,
set an explicit override such as `{ "Mod+E": "markdown.toggle_task" }`.

Physical Enter is claimed before Chromium's textarea default, preserves leading
indentation, and continues bullets, ordered lists, and task checkboxes through
the shared smart-newline planner; Shift+Enter inserts a raw newline.
Ctrl/Cmd+Alt+Up/Down and Ctrl/Cmd+click outside Markdown links add
carets and keep the newest caret active. Vertical additions follow wrapped
visual rows, edits apply to every caret, and Escape clears secondary carets before
arming focus traversal. Multi-range copy/cut joins ranges with newlines.
Simple clicks are hit-tested against the rendered projection's actual grapheme
rectangles and mapped back through display-map segments to canonical source.
This keeps wrapped-line placement exact under host-provided proportional fonts,
font sizes, browser zoom, and device scale. Shift+click and primary-button drag
use the same projection mapping, while keyboard selection remains a semantic
textarea operation. Browser-owned Arrow/Home/End/Page movement reconciles the
projected caret after the browser default on every repeated keydown, without
waiting for an edit. Selection endpoints reveal source; intervening lines stay
projected, and only the visible projection window receives highlight rectangles.
Task toggling preserves content-relative
selection endpoints, and a fresh-line Ctrl/Cmd+E lands after `- [ ] `.
Wrapped indented/list lines use a measured pixel hanging indent, so every
continuation row starts exactly beneath the first row's content rather than a
font-dependent character estimate. An overwide unbroken first token begins
beside the list marker and breaks across following rows instead of stranding
the marker on a row by itself. Inactive headings have a level-specific size
hierarchy, task markers are clickable, and hovering inline or fenced code
reveals a Copy control. Clipboard rejection emits
`continuity-request` with `kind: "copyText"` for host mediation.

## Headless engine use

```js
import { readFile } from "node:fs/promises";
import { Editor, initialize } from "@continuity-editor/editor";

const wasm = await readFile(
  new URL(import.meta.resolve("@continuity-editor/editor/wasm")),
);
await initialize({ wasm });

const editor = new Editor("# Hello", savedRevision);
editor.insertText("!");
editor.executeCommand("markdown.toggle_bold");
console.log(editor.snapshot());
editor.destroy();
```

One JavaScript agent owns each `Editor` or component. Methods are synchronous
after `initialize`; no worker or async runtime is created internally.
`Editor.projection()` returns complete source/display byte maps for headless
hosts. `Editor.presentation()` is the compact DOM-oriented equivalent without
per-byte map arrays; `presentationRange(startLine, endLine)` is its
viewport-scoped form. Mutation reports include ordered `edits` splices; the
component uses them to keep its source mirror and textarea incremental.

## Support and validation

The first supported presentation lane is Chromium and Electron. The automated
lane currently exercises Chrome 150 and Electron 43.1.1; Firefox and WebKit
are not claimed. `browserslist` records a Chrome 126 / Electron 31 API floor,
not a promise that every intervening release receives its own CI job.

Mobile Chromium browsers with predictive/autocorrect keyboards (Android GBoard,
iOS Safari) are a tested lane for the IME composition path: the packed contract
suite reproduces a host document replacement landing mid-composition and asserts
the textarea is never rewritten while composing, that a stale controlled echo is
dropped on `compositionend`, and that successive composed words with intervening
spaces do not compound the document.

Initialization failures reject with `ContinuityInitError`, whose message names
the required WASM MIME type and CSP token while retaining the original cause.

The package is assembled and installed from its tarball by
`cargo xtask wasm-check`. `cargo xtask browser-check` additionally runs the
packed component contract, accessibility-tree and browser performance gates,
10,000-line load/edit/newline/wrap and caret-follow coverage, then the packed Electron IPC persistence
smoke. Set `CONTINUITY_BROWSER_CPU_PROFILE=1` for a diagnostic Chrome hot-frame
report, then rerun without profiling for release measurements. The package is
not yet published to a registry. `wasm-check` also gates edited 10,000-line
viewport projection, installed package size, total JavaScript, and the lazy
entry. SDK release staging requires the full packed browser gate.
