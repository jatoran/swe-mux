/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const __wbg_raweditor_free: (a: number, b: number) => void;
export const raweditor_delete_backward: (a: number, b: number, c: number) => void;
export const raweditor_delete_forward: (a: number, b: number, c: number) => void;
export const raweditor_execute_command: (a: number, b: number, c: number, d: number, e: number) => void;
export const raweditor_fromSnapshot: (a: number, b: number, c: bigint) => number;
export const raweditor_indent: (a: number, b: number, c: number) => void;
export const raweditor_insert_text: (a: number, b: number, c: number, d: number, e: number) => void;
export const raweditor_linear_memory_bytes: (a: number) => number;
export const raweditor_new: (a: number, b: number) => number;
export const raweditor_outdent: (a: number, b: number, c: number) => void;
export const raweditor_presentation_json: (a: number, b: number) => void;
export const raweditor_presentation_range_json: (a: number, b: number, c: number, d: number) => void;
export const raweditor_projection_json: (a: number, b: number) => void;
export const raweditor_reconcile_text_if_revision: (a: number, b: number, c: number, d: number, e: bigint, f: number) => void;
export const raweditor_redo: (a: number, b: number, c: number) => void;
export const raweditor_redo_alternate: (a: number, b: number, c: number) => void;
export const raweditor_set_selections_json: (a: number, b: number, c: number, d: number) => void;
export const raweditor_snapshot_json: (a: number, b: number) => void;
export const raweditor_undo: (a: number, b: number, c: number) => void;
export const __wbindgen_export: (a: number) => void;
export const __wbindgen_add_to_stack_pointer: (a: number) => number;
export const __wbindgen_export2: (a: number, b: number, c: number) => void;
export const __wbindgen_export3: (a: number, b: number) => number;
export const __wbindgen_export4: (a: number, b: number, c: number, d: number) => number;
