import { utf8ByteToUtf16 } from "./coordinates.js";

const LIST_PREFIX = /^[\t ]*(?:[•☐☑]|[-*+]|\d+[.)])[\t ]+/u;
const WRAP_ENCODER = new TextEncoder();
let measureContext;

/** Find the source-visible prefix that wrapped rows hang beneath. */
export function computeSourceWrapPrefix(text) {
  const listPrefix = text.match(LIST_PREFIX)?.[0];
  const prefix = listPrefix ?? text.match(/^[\t ]*/u)?.[0] ?? "";
  return {
    byteEnd: WRAP_ENCODER.encode(prefix).length,
    isListItem: Boolean(listPrefix),
  };
}

/** Apply hanging indent, measuring exact pixels only for realized viewport lines. */
export function applyMeasuredWrapLayout(element, text, prefix, shouldMeasure) {
  if (prefix.byteEnd === 0) {
    if (element.dataset.wrapLayoutFingerprint !== "none") {
      element.style.setProperty("--continuity-wrap-indent", "0px");
      element.dataset.listItem = "false";
      element.dataset.breakUnbroken = "false";
      element.dataset.wrapLayoutFingerprint = "none";
    }
    return;
  }
  const prefixUtf16End = utf8ByteToUtf16(text, prefix.byteEnd);
  const prefixText = text.slice(0, prefixUtf16End);
  if (!shouldMeasure) {
    const columns = computeColumns(prefixText);
    const token = text.slice(prefixUtf16End).match(/^[^\s]+/u)?.[0] ?? "";
    element.style.setProperty("--continuity-wrap-indent", `${columns}ch`);
    element.dataset.listItem = String(prefix.isListItem);
    element.dataset.breakUnbroken = String(prefix.isListItem && token.length > 64);
    element.dataset.wrapLayoutFingerprint = `approximate:${prefixText}:${token.length}`;
    return;
  }
  const style = getComputedStyle(element);
  const layoutFingerprint = `${prefixText}\u0000${style.font}\u0000${element.clientWidth}`;
  if (element.dataset.wrapLayoutFingerprint === layoutFingerprint) return;
  const prefixWidth = measureTextAdvance(prefixText, style);
  element.style.setProperty("--continuity-wrap-indent", `${prefixWidth}px`);
  element.dataset.listItem = String(prefix.isListItem);
  element.dataset.breakUnbroken = String(
    prefix.isListItem && hasOverwideFirstToken(element, text, prefixUtf16End, prefixWidth, style),
  );
  element.dataset.wrapLayoutFingerprint = layoutFingerprint;
}

function computeColumns(text) {
  let columns = 0;
  for (const character of text) {
    columns = character === "\t" ? Math.floor(columns / 4 + 1) * 4 : columns + 1;
  }
  return columns;
}

function hasOverwideFirstToken(element, text, contentStart, prefixWidth, style) {
  const token = text.slice(contentStart).match(/^[^\s]+/u)?.[0] ?? "";
  return token.length > 0
    && measureTextAdvance(token, style) > Math.max(1, element.clientWidth - prefixWidth);
}

function measureTextAdvance(text, style) {
  if (text.length === 0) return 0;
  measureContext ??= document.createElement("canvas").getContext("2d");
  if (!measureContext) return 0;
  measureContext.font = `${style.fontStyle} ${style.fontWeight} ${style.fontSize} ${style.fontFamily}`;
  const tabWidth = measureContext.measureText(" ").width * (parseInt(style.tabSize, 10) || 4);
  let width = 0;
  let runStart = 0;
  for (let index = text.indexOf("\t"); index >= 0; index = text.indexOf("\t", runStart)) {
    width += measureContext.measureText(text.slice(runStart, index)).width;
    width = Math.floor(width / tabWidth + 1) * tabWidth;
    runStart = index + 1;
  }
  return width + measureContext.measureText(text.slice(runStart)).width;
}
