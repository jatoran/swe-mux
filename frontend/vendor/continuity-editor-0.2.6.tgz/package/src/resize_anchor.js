import { measureBrowserTypography, measureTextareaCaretTop } from "./projection.js";

/** Observe browser reflow while preserving the active caret's screen row. */
export function observeEditorResize(host, input, frame, callbacks) {
  let previousScrollHeight = 0;
  const observer = new ResizeObserver(() => {
    const inputWidth = input.getBoundingClientRect().width;
    const previousWidth = callbacks.inputWidth();
    if (callbacks.hasEditor() && previousWidth > 0 && inputWidth !== previousWidth) {
      if (input.selectionEnd === input.value.length && input.selectionStart === input.selectionEnd) {
        const bottomDistance = Math.max(0, previousScrollHeight - callbacks.scrollTop());
        input.scrollTop = Math.max(0, input.scrollHeight - bottomDistance);
      } else {
        const previousCaretTop = measureTextareaCaretTop(input, previousWidth);
        const caretScreenY = previousCaretTop - callbacks.scrollTop();
        const nextCaretTop = measureTextareaCaretTop(input, inputWidth);
        input.scrollTop = Math.max(0, nextCaretTop - caretScreenY);
      }
      callbacks.setScrollTop(input.scrollTop);
    }
    callbacks.setInputWidth(inputWidth);
    const metrics = measureBrowserTypography(input);
    frame.style.setProperty("--continuity-character-width", `${metrics.averageCharacterWidth}px`);
    frame.style.setProperty("--continuity-line-height", `${metrics.lineHeight}px`);
    previousScrollHeight = input.scrollHeight;
    callbacks.scheduleRender(performance.now());
  });
  observer.observe(host);
  return observer;
}
