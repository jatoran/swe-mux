/** Dispatch one composed component protocol event across the shadow boundary. */
export function dispatchEditorEvent(host, name, detail) {
  host.dispatchEvent(new CustomEvent(name, {
    bubbles: true,
    composed: true,
    detail,
  }));
}

/** Publish a browser-policy shortcut decision without consuming the keydown. */
export function dispatchShortcutSuppressed(host, detail) {
  dispatchEditorEvent(host, "continuity-shortcut-suppressed", { version: 1, ...detail });
}

/** Publish the browser-observable paint-ready timing boundary. */
export function dispatchEditorFrame(host, revision, inputStartedAt, paintedAt) {
  dispatchEditorEvent(host, "continuity-frame", {
    version: 1,
    revision,
    inputStartedAt,
    paintedAt,
    latencyMs: paintedAt - inputStartedAt,
  });
}

/** Return the live engine or raise the component lifecycle contract error. */
export function requireLiveEditor(editor, isDestroyed) {
  if (isDestroyed) {
    throw new Error("Continuity editor has been destroyed");
  }
  if (!editor) {
    throw new Error("Continuity editor is not ready; await element.ready");
  }
  return editor;
}
