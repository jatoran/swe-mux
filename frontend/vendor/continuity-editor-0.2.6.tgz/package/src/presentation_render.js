import { selectedLines } from "./coordinates.js";
import { renderCodeAffordances } from "./code_affordances.js";
import {
  createPlainPresentation,
  isProjectionStructuralDirty,
  projectionDetailedRange,
  renderActiveSourceLines,
  renderProjection,
  renderProjectionRange,
  renderProjectionViewport,
  shouldRefreshProjection,
} from "./projection.js";

/** Run the incremental keystroke pass; return false to request a full render. */
export function renderFastPresentation(context) {
  const { snapshot, input, projection, affordances, carets, synchronizer, edits } = context;
  const activeLines = selectedLines(snapshot.text, input);
  if (!renderActiveSourceLines(projection, snapshot, activeLines, edits)) {
    return false;
  }
  const shouldMeasureViewport = edits.some((edit) => (
    edit.startLine !== edit.endLine || edit.insertedText.includes("\n")
  ));
  renderProjectionViewport(projection, input, shouldMeasureViewport);
  synchronizer.afterRender(input, projection, affordances, carets, snapshot);
  return true;
}

/** Run the idle/full presentation pass, preferring a viewport-scoped engine report. */
export function renderEditorPresentation(context) {
  const snapshot = context.editor.snapshot();
  const activeLines = selectedLines(snapshot.text, context.input);
  const detailedRange = projectionDetailedRange(context.projection);
  if (context.syntax === "markdown" && !shouldRefreshProjection(context.projection, activeLines)) {
    context.synchronizer.afterRender(
      context.input, context.projection, context.affordances, context.carets, snapshot,
    );
    return;
  }
  if (context.syntax === "markdown"
      && !isProjectionStructuralDirty(context.projection)
      && detailedRange.end > detailedRange.start) {
    const patch = context.editor.presentationRange(detailedRange.start, detailedRange.end);
    if (renderProjectionRange(
      context.projection, context.input, snapshot, patch, activeLines,
    )) {
      context.synchronizer.afterRender(
        context.input, context.projection, context.affordances, context.carets, snapshot,
      );
      return;
    }
  }
  const presentation = context.syntax === "plain"
    ? createPlainPresentation(snapshot.text)
    : context.editor.presentation();
  renderProjection(context.projection, context.input, snapshot, presentation, activeLines);
  renderCodeAffordances(
    context.affordances,
    context.projection,
    snapshot,
    presentation,
    activeLines,
    context.copyCode,
  );
  context.synchronizer.afterRender(
    context.input, context.projection, context.affordances, context.carets, snapshot,
  );
}
