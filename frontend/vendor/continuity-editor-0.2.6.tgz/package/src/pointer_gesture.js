import { projectionPositionAtPoint } from "./projection.js";

/** Focus and capture one trusted primary pointer for projection-owned dragging. */
export function applyPrimaryPointerCapture(input, event) {
  if (event.detail > 1) return;
  event.preventDefault();
  input.focus({ preventScroll: true });
  if (event.isTrusted && input.setPointerCapture) input.setPointerCapture(event.pointerId);
}

/** Own one physical pointer gesture without conflating it with synthetic clicks. */
export class ProjectionPointerGesture {
  #anchor;
  #origin;
  #position;
  #selectionsBeforePointer;
  #wasDragged = false;

  begin(event, projection, selections) {
    this.#origin = { clientX: event.clientX, clientY: event.clientY };
    this.#position = projectionPositionAtPoint(projection, event.clientX, event.clientY);
    this.#anchor = event.shiftKey && selections[0] ? selections[0].anchor : this.#position;
    this.#selectionsBeforePointer = event.ctrlKey || event.metaKey ? selections : undefined;
    this.#wasDragged = false;
  }

  move(event, projection) {
    if ((event.buttons & 1) === 0 || !this.#origin) return null;
    const horizontal = event.clientX - this.#origin.clientX;
    const vertical = event.clientY - this.#origin.clientY;
    this.#wasDragged ||= horizontal * horizontal + vertical * vertical > 9;
    if (!this.#wasDragged || !this.#anchor) return null;
    const head = projectionPositionAtPoint(projection, event.clientX, event.clientY);
    if (!head) return null;
    event.preventDefault();
    return { anchor: this.#anchor, head };
  }

  complete(event) {
    const horizontal = event.clientX - (this.#origin?.clientX ?? event.clientX);
    const vertical = event.clientY - (this.#origin?.clientY ?? event.clientY);
    const isCapturedClick = Boolean(this.#origin)
      && horizontal * horizontal + vertical * vertical <= 9;
    const result = {
      selection: !this.#wasDragged && event.detail <= 1 && isCapturedClick && this.#position
        ? { anchor: event.shiftKey ? this.#anchor : this.#position, head: this.#position }
        : null,
      selectionsBeforePointer: this.#selectionsBeforePointer,
    };
    this.#anchor = undefined;
    this.#origin = undefined;
    this.#position = undefined;
    this.#selectionsBeforePointer = undefined;
    this.#wasDragged = false;
    return result;
  }
}
