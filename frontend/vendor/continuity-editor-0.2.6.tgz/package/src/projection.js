import {
  sourceLineStarts,
  utf8ByteToUtf16,
} from "./coordinates.js";
import { applySourceEdits } from "./source_lines.js";
import {
  applyMeasuredWrapLayout,
  computeSourceWrapPrefix,
} from "./wrap_layout.js";
import { projectionPointToPosition } from "./pointer_hit_test.js";

const INLINE_PRIORITY = ["link", "checkbox", "code", "strong", "emphasis", "strikethrough"];
const PROJECTION_ENCODER = new TextEncoder();
const PROJECTION_OVERSCAN_VIEWPORTS = 2;
const projectionStates = new WeakMap();

/** Build an identity projection without invoking the Markdown parser. */
export function createPlainPresentation(text) {
  let sourceByte = 0;
  const lines = text.split("\n").map((line) => {
    const byteLength = PROJECTION_ENCODER.encode(line).length;
    const report = {
      text: line,
      wrapIndentByteEnd: PROJECTION_ENCODER.encode(line.match(/^[\t ]*/u)?.[0] ?? "").length,
      sourceToDisplay: [],
      displayToSource: [],
      segments: [{
        kind: "visible",
        startByte: sourceByte,
        endByte: sourceByte + byteLength,
        replacement: "",
      }],
    };
    sourceByte += byteLength + 1;
    return report;
  });
  return { blocks: [], inlines: [], lines };
}

export function renderProjection(container, input, snapshot, projection, activeLines) {
  const sourceLines = snapshot.text.split("\n");
  const lineStarts = sourceLineStarts(snapshot.text);
  const blockClasses = computeBlockClasses(projection.blocks, lineStarts);
  const lineInlines = bucketInlinesByLine(projection.inlines, lineStarts);
  ensureLineElements(container, projection.lines.length);
  const context = {
    activeLines,
    blockClasses,
    detailedRange: { start: 0, end: 0 },
    lineInlines,
    projectedLines: projection.lines.slice(),
    sourceLines,
    hasStructuralDirty: false,
  };
  projectionStates.set(container, context);
  projection.lines.forEach((_, index) => renderProjectionLine(container, context, index, false));
  renderProjectionViewport(container, input);
}

/** Map a client-space click through the rendered projection into source coordinates. */
export function projectionPositionAtPoint(container, clientX, clientY) {
  const context = projectionStates.get(container);
  return context ? projectionPointToPosition(container, context, clientX, clientY) : null;
}

/** Return the rendered state needed to place a visual caret on one source line. */
export function projectionLineLayout(container, lineIndex) {
  const context = projectionStates.get(container);
  const element = container.children[lineIndex];
  if (!context || !element) return null;
  return {
    element,
    line: context.projectedLines[lineIndex],
    sourceText: context.sourceLines[lineIndex] ?? "",
    isDetailed: element.dataset.detailed === "true",
    isSourceVisible: element.dataset.sourceVisible === "true",
  };
}

/** Return the source-line window currently carrying detailed projected DOM. */
export function projectionDetailedRange(container) {
  return projectionStates.get(container)?.detailedRange ?? { start: 0, end: 0 };
}

/** Whether an idle pass can change visible projection rather than the active source line. */
export function shouldRefreshProjection(container, activeLines) {
  const context = projectionStates.get(container);
  if (!context) return true;
  if (context.hasStructuralDirty) return true;
  for (let index = context.detailedRange.start; index < context.detailedRange.end; index += 1) {
    if (!context.projectedLines[index] && !activeLines.has(index)) return true;
  }
  return false;
}

/** Whether Markdown structure, rather than only one active line, may have changed. */
export function isProjectionStructuralDirty(container) {
  return projectionStates.get(container)?.hasStructuralDirty === true;
}

/** Merge a viewport-scoped engine report into an existing projection. */
export function renderProjectionRange(container, input, snapshot, patch, activeLines) {
  const context = projectionStates.get(container);
  if (!context || patch.lineCount !== context.sourceLines.length) return false;
  const relativeBlocks = computeBlockClasses(patch.blocks, patch.lineStarts);
  const relativeInlines = bucketInlinesByLine(patch.inlines, patch.lineStarts);
  for (let offset = 0; offset < patch.lines.length; offset += 1) {
    const index = patch.startLine + offset;
    context.projectedLines[index] = patch.lines[offset];
    context.blockClasses[index] = relativeBlocks[offset] ?? "block-plain";
    context.lineInlines[index] = relativeInlines[offset] ?? [];
  }
  context.activeLines = activeLines;
  context.hasStructuralDirty = false;
  renderProjectionViewport(container, input, false);
  return true;
}

/** Realize projected DOM by measured pixel offsets around the browser viewport. */
export function renderProjectionViewport(container, input, shouldMeasure = true) {
  const context = projectionStates.get(container);
  if (!context || container.children.length === 0) {
    return;
  }
  if (!shouldMeasure) {
    applyProjectionViewportRange(container, context, context.detailedRange);
    return;
  }
  let nextRange = computeProjectionViewportRange(container, input);
  for (let pass = 0; pass < 2; pass += 1) {
    applyProjectionViewportRange(container, context, nextRange);
    const measuredRange = computeProjectionViewportRange(container, input);
    if (measuredRange.start === nextRange.start && measuredRange.end === nextRange.end) {
      break;
    }
    nextRange = measuredRange;
  }
}

function applyProjectionViewportRange(container, context, nextRange) {
  const previousRange = context.detailedRange;
  for (let index = previousRange.start; index < previousRange.end; index += 1) {
    if (index < nextRange.start || index >= nextRange.end) {
      renderProjectionLine(container, context, index, false);
    }
  }
  for (let index = nextRange.start; index < nextRange.end; index += 1) {
    renderProjectionLine(container, context, index, true);
  }
  context.detailedRange = nextRange;
}

function renderProjectionLine(container, context, index, shouldProject) {
  const element = container.children[index];
  const line = context.projectedLines[index];
  if (!element) {
    return;
  }
  const sourceText = context.sourceLines[index] ?? "";
  const canProject = shouldProject && Boolean(line);
  const isSourceVisible = context.activeLines.has(index);
  const text = isSourceVisible || !canProject ? sourceText : line.text;
  const className = line
    ? `line ${context.blockClasses[index] ?? "block-plain"}`
    : "line block-plain";
  const projectedWrapPrefix = line?.wrapIndentByteEnd ?? 0;
  const wrapPrefix = isSourceVisible || !canProject
    ? computeSourceWrapPrefix(text)
    : { byteEnd: projectedWrapPrefix, isListItem: projectedWrapPrefix > 0 && /^[\t ]*(?:[•☐☑]|[-*+]|\d+[.)])[\t ]+/u.test(text) };
  const fingerprint = `${className}\u0000${isSourceVisible}\u0000${wrapPrefix.byteEnd}\u0000${text}\u0000${canProject}`;
  element.className = className;
  element.dataset.line = String(index);
  element.dataset.sourceVisible = String(isSourceVisible);
  if (element.dataset.fingerprint !== fingerprint) {
    const ranges = canProject && !isSourceVisible
      ? inlineRanges(line, context.lineInlines[index])
      : [];
    renderLine(element, text, ranges);
    element.dataset.detailed = String(Boolean(canProject));
    element.dataset.fingerprint = fingerprint;
  }
  applyMeasuredWrapLayout(element, text, wrapPrefix, canProject);
}

export function renderActiveSourceLines(container, snapshot, activeLines, edits = []) {
  const context = projectionStates.get(container);
  if (!context) return false;
  const previousActiveLines = context.activeLines;
  const sourceLines = applySourceEdits(context.sourceLines, edits, snapshot.text);
  context.activeLines = activeLines;
  context.sourceLines = sourceLines;
  context.hasStructuralDirty ||= edits.some(isStructurallySignificantEdit);
  reconcileEditedLines(container, context, edits);
  if (container.children.length !== sourceLines.length) {
    return false;
  }
  const linesToRender = new Set([...previousActiveLines, ...activeLines]);
  edits.forEach((edit) => {
    const insertedLines = countNewlines(edit.insertedText);
    for (let offset = 0; offset <= insertedLines; offset += 1) {
      linesToRender.add(edit.startLine + offset);
    }
  });
  for (const lineIndex of linesToRender) {
    const shouldProject = lineIndex >= context.detailedRange.start
      && lineIndex < context.detailedRange.end;
    renderProjectionLine(container, context, lineIndex, shouldProject);
  }
  return true;
}

function isStructurallySignificantEdit(edit) {
  return edit.removedBytes > 0 || /[\n#*_~`>[\]()-]/u.test(edit.insertedText);
}

function computeProjectionViewportRange(container, input) {
  const overscan = input.clientHeight * PROJECTION_OVERSCAN_VIEWPORTS;
  const visibleStart = Math.max(0, input.scrollTop - overscan);
  const visibleEnd = input.scrollTop + input.clientHeight + overscan;
  const children = container.children;
  return {
    start: lowerBoundLineEnd(children, visibleStart),
    end: lowerBoundLineStart(children, visibleEnd),
  };
}

function lowerBoundLineEnd(children, target) {
  let lower = 0;
  let upper = children.length;
  while (lower < upper) {
    const middle = lower + Math.floor((upper - lower) / 2);
    const line = children[middle];
    if (line.offsetTop + line.offsetHeight < target) lower = middle + 1;
    else upper = middle;
  }
  return lower;
}

function lowerBoundLineStart(children, target) {
  let lower = 0;
  let upper = children.length;
  while (lower < upper) {
    const middle = lower + Math.floor((upper - lower) / 2);
    if (children[middle].offsetTop <= target) lower = middle + 1;
    else upper = middle;
  }
  return lower;
}

function reconcileEditedLines(container, context, edits) {
  for (const edit of edits) {
    const removedLines = edit.endLine - edit.startLine;
    const insertedLines = countNewlines(edit.insertedText);
    invalidateEditedProjection(context, edit.startLine, removedLines, insertedLines);
    if (insertedLines > removedLines) {
      const fragment = document.createDocumentFragment();
      for (let index = removedLines; index < insertedLines; index += 1) {
        const line = document.createElement("div");
        line.className = "line";
        fragment.append(line);
      }
      container.insertBefore(fragment, container.children[edit.startLine + 1] ?? null);
    } else {
      for (let index = insertedLines; index < removedLines; index += 1) {
        container.children[edit.startLine + 1]?.remove();
      }
    }
  }
}

function invalidateEditedProjection(context, startLine, removedLines, insertedLines) {
  if (!context) {
    return;
  }
  const spliceAt = startLine + 1;
  context.projectedLines.splice(spliceAt, removedLines, ...Array(insertedLines).fill(null));
  context.blockClasses.splice(spliceAt, removedLines, ...Array(insertedLines).fill("block-plain"));
  context.lineInlines.splice(
    spliceAt,
    removedLines,
    ...Array.from({ length: insertedLines }, () => []),
  );
  context.projectedLines[startLine] = null;
  context.blockClasses[startLine] = "block-plain";
  context.lineInlines[startLine] = [];
}

function countNewlines(text) {
  let count = 0;
  for (let index = text.indexOf("\n"); index >= 0; index = text.indexOf("\n", index + 1)) {
    count += 1;
  }
  return count;
}

export function synchronizeProjectionScroll(input, ...layers) {
  layers.forEach((layer) => {
    layer.style.transform = `translate(${-input.scrollLeft}px, ${-input.scrollTop}px)`;
  });
}

export function measureBrowserTypography(element) {
  const style = getComputedStyle(element);
  const canvas = document.createElement("canvas");
  const context = canvas.getContext("2d");
  if (!context) {
    return { averageCharacterWidth: 0, lineHeight: parseFloat(style.lineHeight) || 0 };
  }
  context.font = `${style.fontWeight} ${style.fontSize} ${style.fontFamily}`;
  return {
    averageCharacterWidth: context.measureText("abcdefghijklmnopqrstuvwxyz").width / 26,
    lineHeight: parseFloat(style.lineHeight) || parseFloat(style.fontSize) * 1.5,
  };
}

export function measureTextareaCaretTop(input, width = input.getBoundingClientRect().width) {
  const style = getComputedStyle(input);
  const caretOffset = input.selectionDirection === "backward"
    ? input.selectionStart
    : input.selectionEnd;
  const mirror = document.createElement("div");
  mirror.style.cssText = [
    "position:fixed",
    "inset:0 auto auto -10000px",
    "visibility:hidden",
    "pointer-events:none",
    "white-space:pre-wrap",
    "overflow-wrap:anywhere",
    "box-sizing:border-box",
  ].join(";");
  for (const property of [
    "font",
    "letterSpacing",
    "lineHeight",
    "padding",
    "border",
    "tabSize",
    "textIndent",
    "wordSpacing",
  ]) {
    mirror.style[property] = style[property];
  }
  mirror.style.width = `${width}px`;
  mirror.append(document.createTextNode(input.value.slice(0, caretOffset)));
  const caret = document.createElement("span");
  caret.textContent = input.value.slice(caretOffset, caretOffset + 1) || "\u200b";
  mirror.append(caret);
  document.body.append(mirror);
  const top = caret.offsetTop;
  mirror.remove();
  return top;
}

export function revealTextareaCaret(input) {
  const lineHeight = measureBrowserTypography(input).lineHeight;
  const caretTop = measureTextareaCaretTop(input);
  const caretBottom = caretTop + lineHeight;
  const margin = Math.min(lineHeight, Math.max(0, (input.clientHeight - lineHeight) / 2));
  const visibleTop = input.scrollTop;
  const visibleBottom = visibleTop + input.clientHeight;
  if (caretTop < visibleTop + margin) {
    input.scrollTop = Math.max(0, caretTop - margin);
  } else if (caretBottom > visibleBottom - margin) {
    input.scrollTop = caretBottom - input.clientHeight + margin;
  }
  return input.scrollTop;
}

export function findMarkdownLink(text, utf16Offset) {
  const expression = /\[([^\]]+)\]\(([^)\s]+)(?:\s+"[^"]*")?\)/gu;
  for (const match of text.matchAll(expression)) {
    const start = match.index ?? 0;
    const end = start + match[0].length;
    if (utf16Offset >= start && utf16Offset <= end) {
      return { label: match[1], href: match[2] };
    }
  }
  return null;
}

/** Return true when a source offset points at a Markdown task marker. */
export function isMarkdownCheckboxAt(text, utf16Offset) {
  const expression = /^[\t ]*(?:[-*+]|\d+[.)])[\t ]+\[[ xX]\]/gmu;
  for (const match of text.matchAll(expression)) {
    const start = match.index ?? 0;
    if (utf16Offset >= start && utf16Offset <= start + match[0].length) {
      return true;
    }
  }
  return false;
}

function ensureLineElements(container, lineCount) {
  while (container.children.length > lineCount) {
    container.lastElementChild.remove();
  }
  if (container.children.length === lineCount) {
    return;
  }
  const fragment = document.createDocumentFragment();
  for (let index = container.children.length; index < lineCount; index += 1) {
    const line = document.createElement("div");
    line.className = "line";
    fragment.append(line);
  }
  container.append(fragment);
}

function computeBlockClasses(blocks, lineStarts) {
  const classes = Array(lineStarts.length).fill("block-plain");
  for (const block of blocks) {
    let lineIndex = lowerBound(lineStarts, block.startByte);
    while (lineIndex < lineStarts.length && lineStarts[lineIndex] < block.endByte) {
      if (classes[lineIndex] === "block-plain") {
        classes[lineIndex] = `block-${block.kind.replace(":", "-")}`;
      }
      lineIndex += 1;
    }
  }
  return classes;
}

function bucketInlinesByLine(inlines, lineStarts) {
  const buckets = Array.from({ length: lineStarts.length }, () => []);
  for (const span of inlines) {
    if (span.kind.startsWith("marker:") || span.endByte <= span.startByte) {
      continue;
    }
    const firstLine = Math.max(0, upperBound(lineStarts, span.startByte) - 1);
    const lastLine = Math.min(
      lineStarts.length - 1,
      upperBound(lineStarts, span.endByte - 1) - 1,
    );
    for (let lineIndex = firstLine; lineIndex <= lastLine; lineIndex += 1) {
      buckets[lineIndex].push(span);
    }
  }
  return buckets;
}

function lowerBound(values, target) {
  let lower = 0;
  let upper = values.length;
  while (lower < upper) {
    const middle = lower + Math.floor((upper - lower) / 2);
    if (values[middle] < target) {
      lower = middle + 1;
    } else {
      upper = middle;
    }
  }
  return lower;
}

function upperBound(values, target) {
  let lower = 0;
  let upper = values.length;
  while (lower < upper) {
    const middle = lower + Math.floor((upper - lower) / 2);
    if (values[middle] <= target) {
      lower = middle + 1;
    } else {
      upper = middle;
    }
  }
  return lower;
}

function inlineRanges(line, inlines) {
  const ranges = [];
  for (const span of inlines) {
    if (span.kind.startsWith("marker:")) {
      continue;
    }
    const displayRange = computeDisplayRange(line, span);
    if (!displayRange) {
      continue;
    }
    const start = utf8ByteToUtf16(line.text, displayRange.start);
    const end = utf8ByteToUtf16(line.text, displayRange.end);
    ranges.push({
      start,
      end: Math.max(start + 1, end),
      kind: span.kind,
      sourceStart: span.startByte,
      sourceEnd: span.endByte,
    });
  }
  return ranges;
}

function computeDisplayRange(line, span) {
  if (line.displayToSource.length > 0) {
    const bytes = line.displayToSource
      .filter(([, source]) => source >= span.startByte && source < span.endByte)
      .map(([display]) => display);
    return bytes.length > 0 ? { start: Math.min(...bytes), end: Math.max(...bytes) + 1 } : null;
  }
  let displayByte = 0;
  let start;
  let end;
  for (const segment of line.segments) {
    const displayLength = segment.kind === "visible"
      ? segment.endByte - segment.startByte
      : PROJECTION_ENCODER.encode(segment.replacement).byteLength;
    const overlapStart = Math.max(segment.startByte, span.startByte);
    const overlapEnd = Math.min(segment.endByte, span.endByte);
    if (overlapStart < overlapEnd && segment.kind !== "hidden") {
      const offset = segment.kind === "visible" ? overlapStart - segment.startByte : 0;
      start ??= displayByte + offset;
      end = segment.kind === "visible"
        ? displayByte + overlapEnd - segment.startByte
        : displayByte + displayLength;
    }
    displayByte += displayLength;
  }
  return start === undefined ? null : { start, end };
}

function renderLine(element, text, ranges) {
  const boundaries = new Set([0, text.length]);
  ranges.forEach(({ start, end }) => {
    boundaries.add(Math.max(0, Math.min(start, text.length)));
    boundaries.add(Math.max(0, Math.min(end, text.length)));
  });
  const ordered = [...boundaries].sort((left, right) => left - right);
  const fragment = document.createDocumentFragment();
  for (let index = 0; index < ordered.length - 1; index += 1) {
    const start = ordered[index];
    const end = ordered[index + 1];
    const value = text.slice(start, end);
    const active = ranges.filter((range) => range.start <= start && range.end >= end);
    const kind = INLINE_PRIORITY.find((candidate) => active.some((range) => range.kind === candidate));
    if (!kind) {
      fragment.append(document.createTextNode(value));
      continue;
    }
    const span = document.createElement("span");
    span.className = `inline-${kind}`;
    span.textContent = value;
    const sourceRange = active.find((range) => range.kind === kind);
    span.dataset.sourceStart = String(sourceRange.sourceStart);
    span.dataset.sourceEnd = String(sourceRange.sourceEnd);
    fragment.append(span);
  }
  if (text.length === 0) {
    fragment.append(document.createElement("br"));
  }
  element.replaceChildren(fragment);
}
