import { projectionDetailedRange, projectionLineLayout } from "./projection.js";
import {
  appendVisualCarets,
  caretDisplayOffset,
  measureTextOffset,
  measureTextRange,
} from "./visual_carets.js";

const SELECTION_ENCODER = new TextEncoder();

/** Paint visible selection ranges and carets from one canonical engine snapshot. */
export function renderSelectionOverlays(container, projection, snapshot) {
  const containerBounds = container.getBoundingClientRect();
  const fragment = document.createDocumentFragment();
  appendVisualSelections(fragment, projection, snapshot, containerBounds);
  appendVisualCarets(fragment, projection, snapshot, containerBounds);
  container.replaceChildren(fragment);
}

function appendVisualSelections(fragment, projection, snapshot, containerBounds) {
  const detailedRange = projectionDetailedRange(projection);
  snapshot.selections.forEach((selection, selectionIndex) => {
    if (isCollapsed(selection)) return;
    const ordered = orderedSelection(selection);
    const firstLine = Math.max(ordered.start.line, detailedRange.start);
    const lastLine = Math.min(ordered.end.line, detailedRange.end - 1);
    for (let lineIndex = firstLine; lineIndex <= lastLine; lineIndex += 1) {
      appendLineSelection(
        fragment, projection, ordered, lineIndex, selectionIndex, containerBounds,
      );
    }
  });
}

function appendLineSelection(
  fragment, projection, selection, lineIndex, selectionIndex, containerBounds,
) {
  const layout = projectionLineLayout(projection, lineIndex);
  if (!layout) return;
  const lineBytes = SELECTION_ENCODER.encode(layout.sourceText).byteLength;
  const startByte = lineIndex === selection.start.line ? selection.start.byteInLine : 0;
  const endByte = lineIndex === selection.end.line ? selection.end.byteInLine : lineBytes;
  const start = caretDisplayOffset(layout, startByte);
  const end = caretDisplayOffset(layout, endByte);
  const bounds = mergeRowBounds(measureTextRange(layout.element, start, end));
  bounds.forEach((row) => appendSelectionRect(
    fragment, row, selectionIndex, containerBounds,
  ));
  if (lineIndex < selection.end.line) {
    const point = measureTextOffset(layout.element, caretDisplayOffset(layout, lineBytes));
    appendSelectionRect(fragment, {
      left: point.left,
      top: point.top,
      width: Math.max(2, point.height * 0.22),
      height: point.height,
    }, selectionIndex, containerBounds);
  }
}

function appendSelectionRect(fragment, bounds, selectionIndex, containerBounds) {
  const highlight = document.createElement("span");
  highlight.className = "visual-selection";
  highlight.dataset.selectionIndex = String(selectionIndex);
  highlight.style.transform = `translate(${bounds.left - containerBounds.left}px, ${bounds.top - containerBounds.top}px)`;
  highlight.style.width = `${Math.max(1, bounds.width)}px`;
  highlight.style.height = `${bounds.height}px`;
  fragment.append(highlight);
}

function mergeRowBounds(bounds) {
  const ordered = [...bounds].sort((left, right) => left.top - right.top || left.left - right.left);
  const rows = [];
  for (const boundsItem of ordered) {
    const previous = rows.at(-1);
    if (previous
        && Math.abs(previous.top - boundsItem.top) <= 1
        && Math.abs(previous.height - boundsItem.height) <= 1
        && boundsItem.left <= previous.left + previous.width + 1) {
      previous.width = Math.max(previous.width, boundsItem.right - previous.left);
    } else {
      rows.push({
        left: boundsItem.left,
        top: boundsItem.top,
        width: boundsItem.width,
        height: boundsItem.height,
      });
    }
  }
  return rows;
}

function orderedSelection(selection) {
  return positionOrder(selection.anchor, selection.head) <= 0
    ? { start: selection.anchor, end: selection.head }
    : { start: selection.head, end: selection.anchor };
}

function positionOrder(left, right) {
  return left.line - right.line || left.byteInLine - right.byteInLine;
}

function isCollapsed(selection) {
  return positionOrder(selection.anchor, selection.head) === 0;
}
