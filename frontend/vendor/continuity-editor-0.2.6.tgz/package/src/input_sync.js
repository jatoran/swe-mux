import { applySelectionToInput } from "./coordinates.js";
import { revealTextareaCaret, synchronizeProjectionScroll } from "./projection.js";
import { renderSelectionOverlays } from "./selection_overlays.js";

/** Component-agent-owned textarea viewport and synchronization state. */
export class EditorInputSynchronizer {
  #isAtBottom = true;
  #scrollLeft = 0;
  #scrollTop = 0;

  get scrollTop() {
    return this.#scrollTop;
  }

  set scrollTop(value) {
    this.#scrollTop = value;
  }

  onScroll(input, projection, affordances, carets, snapshot) {
    this.#isAtBottom = input.scrollTop + input.clientHeight >= input.scrollHeight - 2;
    this.#scrollLeft = input.scrollLeft;
    this.#scrollTop = input.scrollTop;
    synchronizeProjectionScroll(input, projection, affordances);
    renderSelectionOverlays(carets, projection, snapshot);
  }

  apply(input, snapshot, change, shouldRevealCaret) {
    if (!shouldRevealCaret) {
      this.#scrollLeft = input.scrollLeft;
      this.#scrollTop = input.scrollTop;
    }
    const didPinBottom = synchronizeTextarea(
      input,
      snapshot,
      change,
      shouldRevealCaret,
      this.#isAtBottom,
      this.#scrollTop,
      this.#scrollLeft,
    );
    if (didPinBottom) {
      this.#isAtBottom = true;
    }
    return inputSelectionKey(input);
  }

  afterRender(input, projection, affordances, carets, snapshot) {
    this.#scrollLeft = input.scrollLeft;
    this.#scrollTop = input.scrollTop;
    this.#isAtBottom = this.#scrollTop + input.clientHeight >= input.scrollHeight - 2;
    synchronizeProjectionScroll(input, projection, affordances);
    renderSelectionOverlays(carets, projection, snapshot);
  }
}

/** Incrementally synchronize the semantic textarea with an engine snapshot. */
export function synchronizeTextarea(
  input, snapshot, change, shouldRevealCaret, wasAtBottom, scrollTop, scrollLeft,
) {
  const previousTextLength = computePreviousTextLength(snapshot.text.length, change?.edits);
  const wasAtDocumentEnd = input.selectionEnd === previousTextLength;
  if (change?.edits) {
    change.edits.forEach((edit) => input.setRangeText(
      edit.insertedText, edit.startUtf16, edit.endUtf16, "preserve",
    ));
  } else if (input.value !== snapshot.text) {
    input.value = snapshot.text;
  }
  const selection = snapshot.selections[0];
  if (selection) {
    applySelectionToInput(snapshot.text, selection, input);
  }
  input.scrollLeft = scrollLeft;
  if (shouldRevealCaret && wasAtDocumentEnd && wasAtBottom) {
    input.scrollTop = 1_000_000_000;
    return true;
  } else if (shouldRevealCaret) {
    input.scrollTop = scrollTop;
    revealTextareaCaret(input);
  } else {
    input.scrollTop = scrollTop;
  }
  return false;
}

/** Cheap identity for detecting a browser selection that actually moved. */
export function inputSelectionKey(input) {
  return `${input.selectionStart}:${input.selectionEnd}:${input.selectionDirection}`;
}

function computePreviousTextLength(currentLength, edits = []) {
  return edits.reduce((length, edit) => (
    length - edit.insertedText.length + edit.endUtf16 - edit.startUtf16
  ), currentLength);
}
