/** Route supported beforeinput mutations through the authoritative engine. */
export function handleBeforeInput(event, options) {
  if (options.isReadOnly) {
    event.preventDefault();
    return;
  }
  if (options.isComposing || event.inputType === "insertCompositionText") {
    return;
  }
  const operations = {
    insertText: ["insert", event.data ?? ""],
    insertLineBreak: ["command", "editor.insert_newline_smart"],
    insertParagraph: ["command", "editor.insert_newline_smart"],
    deleteContentBackward: ["deleteBackward"],
    deleteContentForward: ["deleteForward"],
    deleteByCut: ["insert", ""],
    historyUndo: ["undo"],
    historyRedo: ["redo"],
  };
  const operation = operations[event.inputType];
  if (!operation) return;
  event.preventDefault();
  options.applyOperation(operation[0], operation[1]);
}
