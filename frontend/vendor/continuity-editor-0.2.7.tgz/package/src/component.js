import { Editor, initialize } from "./engine.js";
import { applyEditorAttributes, buildEditorDom } from "./component_dom.js";
import { dispatchEditorEvent, dispatchEditorFrame, dispatchShortcutSuppressed, requireLiveEditor } from "./component_events.js";
import { handleCopy, handleCut, handleDrop, handlePaste, normalizeNewlines } from "./input_events.js";
import { selectionFromInput } from "./coordinates.js";
import {
  findMarkdownLink,
  renderProjectionViewport,
} from "./projection.js";
import {
  hideCodeAffordances,
  revealCodeAffordanceAt,
  writeClipboardText,
} from "./code_affordances.js";
import {
  addPointerCaret,
  addVerticalCaret,
  selectionsWithInputPrimary,
} from "./multi_selection.js";
import { renderSelectionOverlays } from "./selection_overlays.js";
import { handleEditorKeyDown, keyboardHelpText } from "./keyboard.js";
import { EditorInputSynchronizer, inputSelectionKey } from "./input_sync.js";
import { handleBeforeInput } from "./native_input.js";
import {
  applyPrimaryPointerCapture, applyProjectedPointerSelection, handleUnmodifiedPointerClick,
  ProjectionPointerGesture,
} from "./pointer_gesture.js";
import { RenderScheduler } from "./render_scheduler.js";
import { renderEditorPresentation, renderFastPresentation } from "./presentation_render.js";
import { planDeferredHostReplace } from "./composition_defer.js";
import { applyPublicSelections, revealPublicRange, restorePublicScroll } from "./navigation.js";
import { observeEditorResize } from "./resize_anchor.js";
import { normalizeShortcutBindings, normalizeShortcutPolicy } from "./shortcuts.js";
import { EDITOR_STYLES } from "./styles.js";
const HTMLElementBase = globalThis.HTMLElement ?? class {};
const EVENT_VERSION = 1;
/** Framework-neutral browser editor backed by the shared synchronous engine. */
export class ContinuityEditorElement extends HTMLElementBase {
  static get observedAttributes() {
    return ["aria-label", "readonly", "shortcut-policy", "spellcheck", "syntax", "tab-behavior", "theme"];
  }
  #abortController;
  #affordances;
  #carets;
  #collapseSelectionsOnPointer = false;
  #deferredHostReplace = null;
  #editor;
  #frame;
  #initialRevision = 0;
  #initialValue;
  #input;
  #inputSynchronizer = new EditorInputSynchronizer();
  #inputWidth = 0;
  #inputSelectionKey = "";
  #isComposing = false;
  #isDestroyed = false;
  #isFocusEscapeArmed = false;
  #keyboardHelp;
  #pointerGesture = new ProjectionPointerGesture();
  #pendingEdits = [];
  #projection;
  #ready;
  #rejectReady;
  #renderScheduler;
  #requestSequence = 0;
  #resizeObserver;
  #resolveReady;
  #isReadySettled = false;
  #shouldFocusWhenReady = false;
  #shortcutBindings = new Map();
  #started = false;
  constructor() {
    super();
    this.#initialValue = normalizeNewlines(this.getAttribute?.("value") ?? this.textContent ?? "");
    this.#ready = new Promise((resolve, reject) => {
      this.#resolveReady = resolve;
      this.#rejectReady = reject;
    });
  }

  /** Resolves when WASM initialization and the first visible projection finish. */
  get ready() {
    return this.#ready;
  }
  get value() {
    return this.#editor?.snapshot().text ?? this.#initialValue;
  }

  set value(nextValue) {
    if (!this.#editor) {
      this.#initialValue = normalizeNewlines(String(nextValue));
      return;
    }
    this.replaceValue(nextValue, this.#editor.snapshot().revision);
  }
  get initialRevision() {
    return this.#editor?.snapshot().revision ?? this.#initialRevision;
  }

  set initialRevision(value) {
    if (this.#editor) {
      throw new Error("initialRevision must be set before the editor is ready");
    }
    if (!Number.isSafeInteger(value) || value < 0) {
      throw new RangeError("initialRevision must be a non-negative safe integer");
    }
    this.#initialRevision = value;
  }
  get readOnly() {
    return this.hasAttribute("readonly");
  }

  set readOnly(value) {
    this.toggleAttribute("readonly", Boolean(value));
  }
  get shortcutPolicy() {
    return normalizeShortcutPolicy(this.getAttribute("shortcut-policy"));
  }

  set shortcutPolicy(value) {
    this.setAttribute("shortcut-policy", normalizeShortcutPolicy(value));
  }
  get shortcutBindings() {
    return new Map(this.#shortcutBindings);
  }

  set shortcutBindings(value) {
    this.#shortcutBindings = normalizeShortcutBindings(value);
  }
  get syntax() { return this.getAttribute("syntax") === "plain" ? "plain" : "markdown"; }
  set syntax(value) { this.setAttribute("syntax", value === "plain" ? "plain" : "markdown"); }
  connectedCallback() {
    if (!this.#started && !this.#isDestroyed) {
      this.#started = true;
      this.#start();
    }
  }
  disconnectedCallback() {
    queueMicrotask(() => {
      if (!this.isConnected) {
        this.destroy();
      }
    });
  }
  attributeChangedCallback(name) {
    this.#applyAttributes();
    if (name === "syntax") this.#renderScheduler?.schedule(performance.now());
  }
  /** Return a complete immutable engine snapshot. */
  snapshot() {
    return { ...this.#requireEditor().snapshot(), isReadOnly: this.readOnly };
  }
  get composing() { return this.#isComposing; }
  /** Replace the complete document only when the host revision is current. */
  replaceValue(value, expectedRevision, timestampMs = Date.now()) {
    const normalized = normalizeNewlines(String(value));
    if (this.#isComposing && this.#editor) {
      this.#deferredHostReplace = { value: normalized, revision: expectedRevision };
      return null;
    }
    const startedAt = performance.now();
    const change = this.#requireEditor().replaceValue(normalized, expectedRevision, timestampMs);
    this.#commitChange(change, startedAt, "hostReplacement");
    return change;
  }
  /** Execute one storage-neutral editor command synchronously. */
  executeCommand(command, timestampMs = Date.now()) {
    return this.#applyOperation("command", String(command), timestampMs);
  }
  /** Replace all engine selections and optionally reveal the primary selection. */
  setSelections(selections, options = {}) {
    const snapshot = applyPublicSelections(this.#requireEditor(), this.#input, selections, options.reveal !== false);
    this.#inputSelectionKey = inputSelectionKey(this.#input);
    this.#renderScheduler?.schedule(performance.now());
    return snapshot;
  }
  /** Reveal a source range and make it the primary selection. */
  revealRange(range, options = {}) {
    revealPublicRange(this.#requireEditor(), this.#input, range, options.align);
    this.#inputSelectionKey = inputSelectionKey(this.#input);
    this.#renderScheduler?.schedule(performance.now());
  }
  /** Capture the textarea viewport for per-document restoration. */
  getScrollState() { return { top: this.#input?.scrollTop ?? 0, left: this.#input?.scrollLeft ?? 0 }; }
  /** Restore a captured textarea viewport. */
  restoreScrollState(state) { restorePublicScroll(
    this.#input, this.#projection, this.#affordances, this.#carets, this.#requireEditor().snapshot(), state,
  ); }
  /** Report current shared WebAssembly linear memory. */
  linearMemoryBytes() { return this.#requireEditor().linearMemoryBytes(); }
  /** Focus the semantic browser input surface. */
  focus(options) {
    if (this.#input) {
      this.#input.focus(options);
    } else {
      this.#shouldFocusWhenReady = true;
    }
  }

  /** Idempotently release the WASM editor and every browser listener. */
  destroy() {
    if (this.#isDestroyed) {
      return;
    }
    this.#isDestroyed = true;
    this.#abortController?.abort();
    this.#resizeObserver?.disconnect();
    this.#renderScheduler?.destroy();
    if (!this.#isReadySettled) {
      this.#isReadySettled = true;
      this.#rejectReady(new Error("Continuity editor was destroyed before becoming ready"));
    }
    this.#editor?.destroy();
    this.#editor = undefined;
    dispatchEditorEvent(this, "continuity-destroy", { version: EVENT_VERSION });
  }

  async #start() {
    try {
      this.#buildShadowTree();
      await initialize();
      if (this.#isDestroyed) {
        return;
      }
      this.#editor = new Editor(this.#initialValue, this.#initialRevision);
      this.#renderScheduler = new RenderScheduler({
        canRender: () => Boolean(this.#editor && !this.#isDestroyed),
        renderFast: () => this.#renderFast(),
        renderFull: () => this.#render(),
        onFrame: (inputStartedAt, paintedAt) => this.#emitFrame(inputStartedAt, paintedAt),
      });
      this.#syncInputFromEngine();
      this.#render();
      this.#isReadySettled = true;
      this.#resolveReady(this);
      if (this.#shouldFocusWhenReady) {
        this.#input.focus();
      }
      dispatchEditorEvent(this, "continuity-ready", {
        version: EVENT_VERSION,
        snapshot: this.snapshot(),
      });
    } catch (error) {
      if (!this.#isReadySettled) {
        this.#isReadySettled = true;
        this.#rejectReady(error);
      }
      this.#emitError(error);
    }
  }

  #buildShadowTree() {
    const dom = buildEditorDom(this, EDITOR_STYLES);
    this.#affordances = dom.affordances;
    this.#carets = dom.carets;
    this.#frame = dom.frame;
    this.#input = dom.input;
    this.#keyboardHelp = dom.keyboardHelp;
    this.#projection = dom.projection;
    this.#applyAttributes();
    this.#installListeners();
  }

  #installListeners() {
    this.#abortController = new AbortController();
    const options = { signal: this.#abortController.signal };
    this.#input.addEventListener("beforeinput", this.#onBeforeInput, options);
    this.#input.addEventListener("input", this.#onInput, options);
    this.#input.addEventListener("compositionstart", this.#onCompositionStart, options);
    this.#input.addEventListener("compositionend", this.#onCompositionEnd, options);
    this.#input.addEventListener("keydown", this.#onKeyDown, options);
    this.#input.addEventListener("pointerdown", this.#onPointerDown, options);
    this.#input.addEventListener("pointermove", this.#onPointerMove, options);
    this.#input.addEventListener("pointerleave", (event) => {
      if (!this.#affordances.contains(event.relatedTarget)) hideCodeAffordances(this.#affordances);
    }, options);
    this.#input.addEventListener("select", this.#onSelection, options);
    this.#input.addEventListener("scroll", this.#onScroll, options);
    this.#input.addEventListener("paste", this.#onPaste, options);
    this.#input.addEventListener("copy", (event) => {
      if (this.#editor) handleCopy(event, this.#editor.snapshot());
    }, options);
    this.#input.addEventListener("cut", this.#onCut, options);
    this.#input.addEventListener("drop", this.#onDrop, options);
    this.#input.addEventListener("dragover", (event) => event.preventDefault(), options);
    this.#input.addEventListener("click", this.#onClick, options);
    this.#input.addEventListener("contextmenu", this.#onContextMenu, options);
    this.#resizeObserver = observeEditorResize(this, this.#input, this.#frame, {
      hasEditor: () => Boolean(this.#editor),
      inputWidth: () => this.#inputWidth,
      scheduleRender: (startedAt) => this.#scheduleRender(startedAt),
      scrollTop: () => this.#inputSynchronizer.scrollTop,
      setInputWidth: (width) => { this.#inputWidth = width; },
      setScrollTop: (scrollTop) => { this.#inputSynchronizer.scrollTop = scrollTop; },
    });
  }

  #onBeforeInput = (event) => {
    handleBeforeInput(event, {
      isReadOnly: this.readOnly,
      isComposing: this.#isComposing,
      applyOperation: (kind, value) => this.#applyOperation(kind, value),
    });
  };

  #onInput = () => {
    if (this.#isComposing || !this.#editor) {
      return;
    }
    const snapshot = this.#editor.snapshot();
    if (this.#input.value !== snapshot.text) {
      const change = this.#editor.replaceValue(this.#input.value, snapshot.revision);
      this.#commitChange(change, performance.now(), "browserReconcile");
    }
  };

  #onCompositionStart = () => {
    if (this.readOnly) {
      return;
    }
    this.#isComposing = true;
    this.#frame.classList.add("composing");
  };

  #onCompositionEnd = () => {
    if (!this.#isComposing || !this.#editor) {
      return;
    }
    this.#isComposing = false;
    this.#frame.classList.remove("composing");
    const snapshot = this.#editor.snapshot();
    const change = this.#editor.replaceValue(this.#input.value, snapshot.revision);
    // Textarea already holds the composed text; sync without re-applying edits (avoids doubling).
    this.#commitChange(change, performance.now(), "compositionCommit", null);
    this.#flushDeferredHostReplace();
  };

  #flushDeferredHostReplace() {
    const plan = planDeferredHostReplace(this.#deferredHostReplace, this.#editor.snapshot());
    this.#deferredHostReplace = null;
    if (!plan) return;
    const change = this.#editor.replaceValue(plan.value, plan.revision);
    this.#commitChange(change, performance.now(), "hostReplacement");
  }

  #onKeyDown = (event) => {
    this.#isFocusEscapeArmed = handleEditorKeyDown(event, {
      executeCommand: (command) => this.#executeShortcut(command),
      isComposing: this.#isComposing,
      isFocusEscapeArmed: this.#isFocusEscapeArmed,
      hasMultipleSelections: this.#editor?.snapshot().selections.length > 1,
      isReadOnly: this.readOnly,
      addVerticalCaret: (direction) => this.#addVerticalCaret(direction),
      clearSecondarySelections: () => this.#clearSecondarySelections(),
      insertRawNewline: () => this.#applyOperation("insert", "\n"),
      onShortcutSuppressed: (detail) => dispatchShortcutSuppressed(this, detail),
      shortcutBindings: this.#shortcutBindings,
      shortcutPolicy: this.shortcutPolicy,
      tabBehavior: this.getAttribute("tab-behavior"),
    });
    if (!event.defaultPrevented && /^(?:Arrow|Home|End|Page)/u.test(event.key)) requestAnimationFrame(this.#onSelection);
  };
  #executeShortcut(command) {
    const directOperation = {
      "editor.indent": "indent",
      "editor.outdent": "outdent",
      "editor.redo": "redo",
      "editor.undo": "undo",
    }[command];
    return directOperation ? this.#applyOperation(directOperation) : this.executeCommand(command);
  }

  #onSelection = () => {
    if (!this.#editor || this.#isComposing) return;
    const snapshot = this.#editor.snapshot();
    const selections = this.#collapseSelectionsOnPointer
      ? [selectionFromInput(this.#input.value, this.#input)]
      : selectionsWithInputPrimary(snapshot, this.#input);
    this.#collapseSelectionsOnPointer = false;
    this.#editor.setSelections(selections);
    this.#inputSelectionKey = inputSelectionKey(this.#input);
    this.#scheduleRender(performance.now());
  };
  #onPointerDown = (event) => {
    if (!this.#editor || event.button !== 0) {
      return;
    }
    applyPrimaryPointerCapture(this.#input, event);
    if (!event.ctrlKey && !event.metaKey) {
      this.#collapseSelectionsOnPointer = true;
    }
    this.#pointerGesture.begin(event, this.#projection, this.#editor.snapshot().selections);
  };

  #onPointerMove = (event) => {
    revealCodeAffordanceAt(this.#affordances, event.clientX, event.clientY);
    this.#applyProjectedPointerSelection(this.#pointerGesture.move(event, this.#projection));
  };

  #onScroll = () => {
    renderProjectionViewport(this.#projection, this.#input);
    this.#inputSynchronizer.onScroll(
      this.#input, this.#projection, this.#affordances, this.#carets, this.#editor.snapshot(),
    );
  };

  #onPaste = (event) => {
    handlePaste(event, this.readOnly, (text) => this.#applyOperation("insert", text));
  };

  #onCut = (event) => {
    handleCut(
      event,
      this.readOnly,
      this.#editor?.snapshot() ?? { text: this.#input.value, selections: [] },
      this.#input,
      () => this.#applyOperation("insert", ""),
    );
  };

  #onDrop = (event) => {
    handleDrop(
      event,
      this.readOnly,
      (files) => this.#emitRequest("filesDropped", { files }),
      (text) => this.#applyOperation("insert", text),
    );
  };

  #onClick = (event) => {
    const gesture = this.#pointerGesture.complete(event);
    this.#applyProjectedPointerSelection(gesture.selection);
    if (handleUnmodifiedPointerClick(
      event, gesture, this.#editor, this.#input,
      () => { this.#syncInputFromEngine(); this.#scheduleRender(performance.now()); },
      () => this.executeCommand("markdown.toggle_checkbox"),
    )) {
      this.#collapseSelectionsOnPointer = false;
      return;
    }
    const link = findMarkdownLink(this.#input.value, this.#input.selectionStart);
    if (link) {
      this.#emitRequest("openLink", link);
    } else if (this.#editor && gesture.selectionsBeforePointer) {
      this.#editor.setSelections(addPointerCaret(
        this.#input.value,
        gesture.selectionsBeforePointer,
        this.#input,
      ));
      this.#syncInputFromEngine();
      renderSelectionOverlays(this.#carets, this.#projection, this.#editor.snapshot());
      this.#scheduleRender(performance.now());
    }
  };
  #applyProjectedPointerSelection(selection) {
    const selectionKey = applyProjectedPointerSelection(this.#editor, this.#input, selection);
    if (selectionKey !== null) this.#inputSelectionKey = selectionKey;
    if (selectionKey !== null) this.#scheduleRender(performance.now());
  }
  #addVerticalCaret(direction) {
    if (!this.#editor) {
      return;
    }
    this.#editor.setSelections(addVerticalCaret(this.#editor.snapshot(), direction, this.#input));
    this.#syncInputFromEngine();
    renderSelectionOverlays(this.#carets, this.#projection, this.#editor.snapshot());
    this.#scheduleRender(performance.now());
  }
  #clearSecondarySelections() {
    if (!this.#editor) {
      return;
    }
    this.#editor.setSelections([selectionFromInput(this.#input.value, this.#input)]);
    this.#inputSelectionKey = inputSelectionKey(this.#input);
    this.#scheduleRender(performance.now());
  }
  #onContextMenu = (event) => {
    this.#emitRequest("contextMenu", { clientX: event.clientX, clientY: event.clientY });
  };

  #applyOperation(kind, value, timestamp = Date.now()) {
    if (this.readOnly || !this.#editor) {
      return null;
    }
    const startedAt = performance.now();
    const selectionKey = inputSelectionKey(this.#input);
    if (selectionKey !== this.#inputSelectionKey) {
      this.#editor.setSelections(selectionsWithInputPrimary(this.#editor.snapshot(), this.#input));
      this.#inputSelectionKey = selectionKey;
    }
    const operations = {
      insert: () => this.#editor.insertText(value, timestamp),
      deleteBackward: () => this.#editor.deleteBackward(timestamp),
      deleteForward: () => this.#editor.deleteForward(timestamp),
      indent: () => this.#editor.indent(timestamp),
      outdent: () => this.#editor.outdent(timestamp),
      undo: () => this.#editor.undo(timestamp),
      redo: () => this.#editor.redo(timestamp),
      command: () => this.#editor.executeCommand(value, timestamp),
    };
    try {
      const change = operations[kind]?.();
      this.#commitChange(change, startedAt, kind === "command" ? `command:${value}` : kind);
      return change;
    } catch (error) {
      this.#emitError(error);
      throw error;
    }
  }

  #commitChange(change, startedAt, source, syncChange = change) {
    if (!this.#editor) {
      return;
    }
    this.#syncInputFromEngine(source !== "hostReplacement", syncChange);
    this.#pendingEdits.push(...(change?.edits ?? []));
    if (change) {
      dispatchEditorEvent(this, "continuity-change", {
        version: EVENT_VERSION,
        sequence: ++this.#requestSequence,
        source,
        commitOrigin: source === "hostReplacement" ? "host" : "user",
        change,
        snapshot: this.snapshot(),
      });
    }
    this.#scheduleRender(startedAt);
  }

  #syncInputFromEngine(shouldRevealCaret = false, change = null) {
    const snapshot = this.#editor.snapshot();
    this.#inputSelectionKey = this.#inputSynchronizer.apply(
      this.#input,
      snapshot,
      change,
      shouldRevealCaret,
    );
    this.#inputSynchronizer.onScroll(
      this.#input, this.#projection, this.#affordances, this.#carets, snapshot,
    );
  }

  #scheduleRender(startedAt) {
    this.#renderScheduler?.schedule(startedAt);
  }

  #emitFrame(inputStartedAt, paintedAt) {
    dispatchEditorFrame(this, this.#editor.snapshot().revision, inputStartedAt, paintedAt);
  }

  #renderFast() {
    const rendered = renderFastPresentation({
      snapshot: this.#editor.snapshot(), input: this.#input, projection: this.#projection,
      affordances: this.#affordances, carets: this.#carets, synchronizer: this.#inputSynchronizer,
      edits: this.#pendingEdits.splice(0),
    });
    if (!rendered) this.#render();
  }

  #render() {
    renderEditorPresentation({
      editor: this.#editor, syntax: this.syntax, input: this.#input,
      projection: this.#projection, affordances: this.#affordances, carets: this.#carets,
      synchronizer: this.#inputSynchronizer, copyCode: (text) => this.#copyCode(text),
    });
  }

  async #copyCode(text) {
    try {
      await writeClipboardText(text);
    } catch (error) {
      this.#emitRequest("copyText", { text });
      this.#emitError(error);
      throw error;
    } finally {
      this.#input.focus({ preventScroll: true });
    }
  }

  #applyAttributes() {
    applyEditorAttributes(this, this.#input, this.#keyboardHelp, keyboardHelpText);
  }

  #emitRequest(kind, payload) {
    dispatchEditorEvent(this, "continuity-request", {
      version: EVENT_VERSION,
      sequence: ++this.#requestSequence,
      kind,
      ...payload,
    });
  }

  #emitError(error) {
    dispatchEditorEvent(this, "continuity-error", { version: EVENT_VERSION, error });
  }

  #requireEditor() {
    return requireLiveEditor(this.#editor, this.#isDestroyed);
  }
}
