import { Editor, applyEditorOperation, initialize } from "./engine.js";
import { attachCommandRail } from "./command_rail.js";
import { applyEditorAttributes, buildEditorDom } from "./component_dom.js";
import { dispatchEditorEvent, dispatchEditorFrame, dispatchShortcutSuppressed, requireLiveEditor } from "./component_events.js";
import { handleCopy, handleCut, handleDrop, handlePaste, normalizeNewlines } from "./input_events.js";
import {
  clearProjectionCompositionLine,
  renderProjectionViewport,
} from "./projection.js";
import { hideCodeAffordances } from "./code_affordances.js";
import {
  copyCodeBlock, copyText, createClipboardHooks, readClipboardText,
} from "./clipboard_bridge.js";
import { selectionsWithInputPrimary } from "./multi_selection.js";
import { handleEditorKeyDown, keyboardHelpText } from "./keyboard.js";
import { EditorInputSynchronizer, inputSelectionKey } from "./input_sync.js";
import { handleBeforeInput } from "./native_input.js";
import { ProjectionPointerGesture } from "./pointer_gesture.js";
import {
  applyPendingProjectedSelection, applyVerticalCaret, clearSecondarySelections,
  completeProjectedPointerClick, handlePointerCancel, handlePointerDown, handlePointerMove,
  handlePointerUp, handleSelectStart, handleTouchLongPress, handleTouchMove, runSelectionAction,
  isSurfaceEvent, routeSurfacePointer,
} from "./component_pointer.js";
import { NativeSelectionWatcher, applyNativeSelection } from "./native_selection.js";
import { TouchSelectionGesture } from "./touch_selection.js";
import { DragAutoScroller } from "./drag_autoscroll.js";
import { createSelectionActions } from "./selection_actions.js";
import { RenderScheduler } from "./render_scheduler.js";
import { renderEditorPresentation, renderFastPresentation } from "./presentation_render.js";
import { reconcileTextareaMutation } from "./textarea_reconcile.js";
import {
  hostScrollState, restoreHostScroll, revealHostRange, setHostSelections,
} from "./host_navigation.js";
import { observeEditorResize } from "./resize_anchor.js";
import { directShortcutOperation, normalizeShortcutBindings, normalizeShortcutPolicy } from "./shortcuts.js";
import { EDITOR_STYLES } from "./styles.js";
import { installEditorListeners } from "./component_listeners.js";
import {
  commitComposition, flushDeferredHostReplace, renderComposingPresentation,
} from "./component_composition.js";
import { isTouchScrolling } from "./scroll_surface.js";
const HTMLElementBase = globalThis.HTMLElement ?? class {};
const EVENT_VERSION = 1;
/** Framework-neutral browser editor backed by the shared synchronous engine. */
export class ContinuityEditorElement extends HTMLElementBase {
  static get observedAttributes() {
    return ["aria-label", "command-rail", "readonly", "shortcut-policy", "spellcheck", "syntax", "tab-behavior", "theme"];
  }
  #abortController;
  #affordances;
  #carets;
  #collapseSelectionsOnPointer = false;
  #commandRail;
  #composedRunLength = 0;
  #deferredHostReplace = null;
  #editor;
  #frame;
  #initialRevision = 0;
  #initialValue;
  #input;
  #inputSynchronizer = new EditorInputSynchronizer();
  #nativeSelectionWatcher;
  #touchSelection = new TouchSelectionGesture();
  #autoScroller = new DragAutoScroller();
  #selectionActions;
  #inputWidth = 0;
  #inputSelectionKey = "";
  #isComposing = false;
  #isDestroyed = false;
  #isFocusEscapeArmed = false;
  #keyboardHelp;
  #pointerGesture = new ProjectionPointerGesture();
  #pointerContext;
  #pendingEdits = [];
  #pendingPointerSelection = null;
  #projection;
  #ready;
  #shield;
  #surface;
  #rejectReady;
  #renderScheduler;
  #requestSequence = 0;
  #resizeObserver;
  #resolveReady;
  #isReadySettled = false;
  #shouldFocusWhenReady = false;
  #shortcutBindings = new Map();
  #started = false;
  constructor() {
    super();
    this.#initialValue = normalizeNewlines(this.getAttribute?.("value") ?? this.textContent ?? "");
    this.#ready = new Promise((resolve, reject) => {
      this.#resolveReady = resolve;
      this.#rejectReady = reject;
    });
  }

  /** Resolves when WASM initialization and the first visible projection finish. */
  get ready() {
    return this.#ready;
  }
  get value() {
    return this.#editor?.snapshot().text ?? this.#initialValue;
  }

  set value(nextValue) {
    if (!this.#editor) {
      this.#initialValue = normalizeNewlines(String(nextValue));
      return;
    }
    this.replaceValue(nextValue, this.#editor.snapshot().revision);
  }
  get initialRevision() {
    return this.#editor?.snapshot().revision ?? this.#initialRevision;
  }

  set initialRevision(value) {
    if (this.#editor) {
      throw new Error("initialRevision must be set before the editor is ready");
    }
    if (!Number.isSafeInteger(value) || value < 0) {
      throw new RangeError("initialRevision must be a non-negative safe integer");
    }
    this.#initialRevision = value;
  }
  get readOnly() {
    return this.hasAttribute("readonly");
  }

  set readOnly(value) {
    this.toggleAttribute("readonly", Boolean(value));
  }
  get shortcutPolicy() {
    return normalizeShortcutPolicy(this.getAttribute("shortcut-policy"));
  }

  set shortcutPolicy(value) {
    this.setAttribute("shortcut-policy", normalizeShortcutPolicy(value));
  }
  get shortcutBindings() {
    return new Map(this.#shortcutBindings);
  }

  set shortcutBindings(value) {
    this.#shortcutBindings = normalizeShortcutBindings(value);
  }
  get syntax() { return this.getAttribute("syntax") === "plain" ? "plain" : "markdown"; }
  set syntax(value) { this.setAttribute("syntax", value === "plain" ? "plain" : "markdown"); }
  connectedCallback() {
    if (!this.#started && !this.#isDestroyed) {
      this.#started = true;
      this.#start();
    }
  }
  disconnectedCallback() {
    queueMicrotask(() => {
      if (!this.isConnected) {
        this.destroy();
      }
    });
  }
  attributeChangedCallback(name) {
    this.#applyAttributes();
    if (name === "syntax") this.#renderScheduler?.schedule(performance.now());
  }
  /** Return a complete immutable engine snapshot. */
  snapshot() {
    return { ...this.#requireEditor().snapshot(), isReadOnly: this.readOnly };
  }
  get composing() { return this.#isComposing; }
  /** Replace the complete document only when the host revision is current. */
  replaceValue(value, expectedRevision, timestampMs = Date.now()) {
    const normalized = normalizeNewlines(String(value));
    if (this.#isComposing && this.#editor) {
      this.#deferredHostReplace = { value: normalized, revision: expectedRevision };
      return null;
    }
    const startedAt = performance.now();
    const change = this.#requireEditor().replaceValue(normalized, expectedRevision, timestampMs);
    this.#commitChange(change, startedAt, "hostReplacement");
    return change;
  }
  /** Execute one storage-neutral editor command synchronously. */
  executeCommand(command, timestampMs = Date.now()) {
    return this.#applyOperation("command", String(command), timestampMs);
  }
  /** Replace all engine selections and optionally reveal the primary selection. */
  setSelections(selections, options = {}) {
    return setHostSelections(this.#pointerContext, this.#requireEditor(), selections, options);
  }
  /** Reveal a source range and make it the primary selection. */
  revealRange(range, options = {}) {
    revealHostRange(this.#pointerContext, this.#requireEditor(), range, options);
  }
  /** Capture the viewport for per-document restoration. */
  getScrollState() { return hostScrollState(this.#pointerContext); }
  /** Restore a captured viewport. */
  restoreScrollState(state) {
    restoreHostScroll(this.#pointerContext, this.#requireEditor().snapshot(), state);
  }
  /** Report current shared WebAssembly linear memory. */
  linearMemoryBytes() { return this.#requireEditor().linearMemoryBytes(); }
  /** Focus the semantic browser input surface. */
  focus(options) {
    if (this.#input) {
      this.#input.focus(options);
    } else {
      this.#shouldFocusWhenReady = true;
    }
  }

  /** Idempotently release the WASM editor and every browser listener. */
  destroy() {
    if (this.#isDestroyed) return;
    this.#isDestroyed = true;
    this.#pendingPointerSelection = null;
    this.#nativeSelectionWatcher?.destroy();
    if (this.#projection) clearProjectionCompositionLine(this.#projection);
    this.#abortController?.abort();
    this.#resizeObserver?.disconnect();
    this.#renderScheduler?.destroy();
    if (!this.#isReadySettled) {
      this.#isReadySettled = true;
      this.#rejectReady(new Error("Continuity editor was destroyed before becoming ready"));
    }
    this.#editor?.destroy();
    this.#editor = undefined;
    dispatchEditorEvent(this, "continuity-destroy", { version: EVENT_VERSION });
  }

  async #start() {
    try {
      this.#buildShadowTree();
      await initialize();
      if (this.#isDestroyed) {
        return;
      }
      this.#editor = new Editor(this.#initialValue, this.#initialRevision);
      this.#renderScheduler = new RenderScheduler({
        canRender: () => Boolean(this.#editor && !this.#isDestroyed && !this.#isComposing),
        renderFast: () => this.#renderFast(),
        renderFull: () => this.#render(),
        onFrame: (inputStartedAt, paintedAt) => dispatchEditorFrame(
          this, this.#editor.snapshot().revision, inputStartedAt, paintedAt,
        ),
      });
      this.#syncInputFromEngine();
      this.#render();
      this.#isReadySettled = true;
      this.#resolveReady(this);
      if (this.#shouldFocusWhenReady) {
        this.#input.focus();
      }
      dispatchEditorEvent(this, "continuity-ready", {
        version: EVENT_VERSION,
        snapshot: this.snapshot(),
      });
    } catch (error) {
      if (!this.#isReadySettled) {
        this.#isReadySettled = true;
        this.#rejectReady(error);
      }
      this.#emitError(error);
    }
  }

  #buildShadowTree() {
    const dom = buildEditorDom(this, EDITOR_STYLES);
    this.#affordances = dom.affordances;
    this.#carets = dom.carets;
    this.#frame = dom.frame;
    this.#input = dom.input;
    this.#keyboardHelp = dom.keyboardHelp;
    this.#projection = dom.projection;
    this.#shield = dom.shield;
    this.#surface = {
      input: dom.input, projection: dom.projection, affordances: dom.affordances,
      carets: dom.carets, frame: dom.frame, shield: dom.shield, shieldSpacer: dom.shieldSpacer,
      onSelectionPainted: () => this.#selectionActions?.update(),
    };
    this.#inputSynchronizer.configure(this.#surface);
    this.#clipboardHooks = createClipboardHooks({
      input: this.#input,
      emitRequest: (k, p) => this.#emitRequest(k, p), emitError: (e) => this.#emitError(e),
    });

    this.#pointerContext = {
      ...this.#surface,
      gesture: this.#pointerGesture,
      touchSelection: this.#touchSelection,
      autoScroller: this.#autoScroller,
      scroller: () => this.#inputSynchronizer.scroller,
      editor: () => this.#editor,
      isComposing: () => this.#isComposing,
      getPending: () => this.#pendingPointerSelection,
      setPending: (v) => { this.#pendingPointerSelection = v; },
      getCollapse: () => this.#collapseSelectionsOnPointer,
      setCollapse: (v) => { this.#collapseSelectionsOnPointer = v; },
      renderComposing: () => this.#renderComposingPresentation(),
      commitComposition: () => this.#commitComposition(),
      getSelectionKey: () => this.#inputSelectionKey,
      setSelectionKey: (k) => { this.#inputSelectionKey = k; },
      surface: () => (isTouchScrolling() ? this.#shield : this.#input),
      sync: () => this.#syncInputFromEngine(),
      schedule: () => this.#scheduleRender(performance.now()),
      emitRequest: (kind, payload) => this.#emitRequest(kind, payload),
      executeCommand: (command) => this.executeCommand(command),
      setComposing: (v) => { this.#isComposing = v; }, composedRunLength: () => this.#composedRunLength,
      commitChange: (change, source, sync) => this.#commitChange(change, performance.now(), source, sync),
      getDeferredReplace: () => this.#deferredHostReplace,
      setDeferredReplace: (v) => { this.#deferredHostReplace = v; },
      insertText: (text) => this.#applyOperation("insert", text),
      writeClipboard: (text) => copyText(text, this.#clipboardHooks),
      readClipboard: () => readClipboardText(this.#clipboardHooks),

      updateSelectionActions: () => this.#selectionActions?.update(), hideSelectionActions: () => this.#selectionActions?.hide(),    };

    this.#selectionActions = createSelectionActions(this.#surface, {
      isEnabled: () => isTouchScrolling() && !this.#isComposing && !this.#touchSelection.isActive,
      canPaste: () => Boolean(navigator.clipboard?.readText),
      captureSelection: () => this.#input.value.slice(this.#input.selectionStart, this.#input.selectionEnd),
      run: (action, text) => runSelectionAction(this.#pointerContext, action, text),
    });
    this.#applyTouchScrolling();
    this.#installListeners();
    this.#commandRail = attachCommandRail(
      this, dom, (command) => this.#executeShortcut(command), this.#abortController.signal,
    );
    this.#applyAttributes();
  }

  #installListeners() {
    this.#abortController = new AbortController();
    const options = { signal: this.#abortController.signal };
    this.#nativeSelectionWatcher = new NativeSelectionWatcher({
      input: this.#input,
      canAdopt: () => Boolean(this.#editor) && !this.#isComposing && !this.#isDestroyed,
      currentKey: () => this.#inputSelectionKey,
      adopt: () => this.#onSelection(),
    });
    installEditorListeners(this.#surface, {
      onBeforeInput: this.#onBeforeInput,
      onInput: this.#onInput,
      onCompositionStart: this.#onCompositionStart,
      onCompositionEnd: this.#onCompositionEnd,
      onKeyDown: this.#onKeyDown,
      onSelectStart: this.#onSelectStart,
      onSelection: this.#onSelection,
      onSelectionChange: this.#nativeSelectionWatcher.onSelectionChange,
      onScroll: this.#onScroll,
      onPaste: this.#onPaste,
      onCut: this.#onCut,
      onDrop: this.#onDrop,
      onPointerDown: this.#onPointerDown,
      onPointerMove: this.#onPointerMove,
      onPointerCancel: this.#onPointerCancel,
      onPointerUp: this.#onPointerUp,
      onClick: this.#onClick,
      onContextMenu: this.#onContextMenu,
      onTouchPointerChange: this.#applyTouchScrolling,
      onTouchMove: this.#onTouchMove,
    }, {
      snapshot: () => this.#editor?.snapshot(),
    }, options);
    this.#resizeObserver = observeEditorResize(this, this.#input, this.#frame, {
      hasEditor: () => Boolean(this.#editor),
      inputWidth: () => this.#inputWidth,
      scheduleRender: (startedAt) => this.#scheduleRender(startedAt),
      scrollTop: () => this.#inputSynchronizer.scrollTop,
      setInputWidth: (width) => { this.#inputWidth = width; },
      setScrollTop: (scrollTop) => { this.#inputSynchronizer.scrollTop = scrollTop; },
    });
  }

  #onBeforeInput = (event) => {
    handleBeforeInput(event, {
      isReadOnly: this.readOnly,
      isComposing: this.#isComposing,
      applyOperation: (kind, value) => this.#applyOperation(kind, value),
    });
  };

  #onInput = (event) => {
    if (this.#isComposing) {
      // Preview the live composing line only; the engine stays untouched.
      this.#composedRunLength = event?.data?.length ?? 0;
      this.#renderComposingPresentation();
      return;
    }
    if (!this.#editor) return;
    const change = reconcileTextareaMutation(this.#editor, this.#input);
    if (change) {
      // Textarea already holds the mutated text; sync without re-applying edits.
      this.#commitChange(change, performance.now(), "browserReconcile", null);
    }
  };

  #renderComposingPresentation() {
    renderComposingPresentation(this.#pointerContext);
  }

  #onCompositionStart = () => {
    if (this.readOnly) return;
    this.#isComposing = true;
    this.#composedRunLength = 0;
    this.#pendingPointerSelection = null;
  };

  #commitComposition = () => commitComposition(this.#pointerContext);

  #onCompositionEnd = () => {
    if (!this.#commitComposition()) return;
    // A tap that landed while the engine still held pre-composition text was
    // deferred; now the engine matches the textarea, apply it canonically.
    applyPendingProjectedSelection(this.#pointerContext);
    flushDeferredHostReplace(this.#pointerContext);
  };

  #onKeyDown = (event) => {
    this.#isFocusEscapeArmed = handleEditorKeyDown(event, {
      executeCommand: (command) => this.#executeShortcut(command),
      isComposing: this.#isComposing,
      isFocusEscapeArmed: this.#isFocusEscapeArmed,
      hasMultipleSelections: this.#editor?.snapshot().selections.length > 1,
      isReadOnly: this.readOnly,
      addVerticalCaret: (direction) => applyVerticalCaret(this.#pointerContext, direction),
      clearSecondarySelections: () => clearSecondarySelections(this.#pointerContext),
      insertRawNewline: () => this.#applyOperation("insert", "\n"),
      onShortcutSuppressed: (detail) => dispatchShortcutSuppressed(this, detail),
      shortcutBindings: this.#shortcutBindings,
      shortcutPolicy: this.shortcutPolicy,
      tabBehavior: this.getAttribute("tab-behavior"),
    });
    if (!event.defaultPrevented && /^(?:Arrow|Home|End|Page)/u.test(event.key)) requestAnimationFrame(this.#onSelection);
  };
  #executeShortcut(command) {
    const directOperation = directShortcutOperation(command);
    return directOperation ? this.#applyOperation(directOperation) : this.executeCommand(command);
  }

  #onSelection = () => applyNativeSelection(this.#pointerContext);
  #onPointerDown = (event) => {
    this.#selectionActions?.hide();
    routeSurfacePointer(this.#pointerContext, event, handlePointerDown);
  };

  #onPointerMove = (event) => routeSurfacePointer(this.#pointerContext, event, handlePointerMove);

  #onPointerUp = (event) => routeSurfacePointer(this.#pointerContext, event, handlePointerUp);

  #onPointerCancel = () => handlePointerCancel(this.#pointerContext);
  #onSelectStart = (event) => handleSelectStart(this.#pointerContext, event);
  #onTouchMove = (event) => handleTouchMove(this.#pointerContext, event);

  // The class drives the stylesheet and the same predicate picks the scroller in
  // JS, so the two can never disagree about which element owns the touch.
  #applyTouchScrolling = () => {
    this.#frame.classList.toggle("touch-scrolling", isTouchScrolling());
    this.#scheduleRender(performance.now());
  };

  // The bar follows the selection rather than dismissing: it is anchored to the
  // highlight, which moves with the projection.
  #onScroll = () => {
    this.#selectionActions?.update();
    renderProjectionViewport(this.#projection, this.#inputSynchronizer.scroller);
    this.#inputSynchronizer.onScroll(this.#editor.snapshot());
    // Scrolling may re-realize the composing line from stale engine text and
    // repaint stale engine overlays; the live preview repaint wins the turn.
    if (this.#isComposing) this.#renderComposingPresentation();
  };

  #onPaste = (event) => {
    handlePaste(event, this.readOnly, (text) => this.#applyOperation("insert", text));
  };

  #onCut = (event) => {
    handleCut(
      event,
      this.readOnly,
      this.#editor?.snapshot() ?? { text: this.#input.value, selections: [] },
      this.#input,
      () => this.#applyOperation("insert", ""),
    );
  };

  #onDrop = (event) => {
    handleDrop(
      event,
      this.readOnly,
      (files) => this.#emitRequest("filesDropped", { files }),
      (text) => this.#applyOperation("insert", text),
    );
  };

  #onClick = (event) => routeSurfacePointer(
    this.#pointerContext, event, completeProjectedPointerClick,
  );

  #onContextMenu = (event) => {
    if (!isSurfaceEvent(this.#pointerContext, event)) return;
    // On touch this is the platform's long-press signal. Claim it so selection
    // stays on projected geometry; the host still hears the request either way.
    const didClaim = handleTouchLongPress(this.#pointerContext, event);
    this.#emitRequest("contextMenu", {
      clientX: event.clientX, clientY: event.clientY, isLongPressSelection: didClaim,
    });
  };

  #applyOperation(kind, value, timestamp = Date.now()) {
    if (this.readOnly || !this.#editor) return null;
    const startedAt = performance.now();
    const selectionKey = inputSelectionKey(this.#input);
    if (selectionKey !== this.#inputSelectionKey) {
      this.#editor.setSelections(selectionsWithInputPrimary(this.#editor.snapshot(), this.#input));
      this.#inputSelectionKey = selectionKey;
    }
    try {
      const change = applyEditorOperation(this.#editor, kind, value, timestamp);
      this.#commitChange(change, startedAt, kind === "command" ? `command:${value}` : kind);
      return change;
    } catch (error) {
      this.#emitError(error);
      throw error;
    }
  }

  #commitChange(change, startedAt, source, syncChange = change) {
    if (!this.#editor) return;
    this.#syncInputFromEngine(source !== "hostReplacement", syncChange);
    this.#pendingEdits.push(...(change?.edits ?? []));
    if (change) {
      dispatchEditorEvent(this, "continuity-change", {
        version: EVENT_VERSION,
        sequence: ++this.#requestSequence,
        source,
        commitOrigin: source === "hostReplacement" ? "host" : "user",
        change,
        snapshot: this.snapshot(),
      });
    }
    this.#scheduleRender(startedAt);
  }

  #syncInputFromEngine(shouldRevealCaret = false, change = null) {
    const snapshot = this.#editor.snapshot();
    this.#inputSelectionKey = this.#inputSynchronizer.apply(snapshot, change, shouldRevealCaret);
    this.#inputSynchronizer.onScroll(snapshot);
  }

  #scheduleRender(startedAt) {
    this.#renderScheduler?.schedule(startedAt);
  }

  #renderFast() {
    const rendered = renderFastPresentation({
      snapshot: this.#editor.snapshot(), input: this.#input, projection: this.#projection,
      affordances: this.#affordances, carets: this.#carets, synchronizer: this.#inputSynchronizer,
      edits: this.#pendingEdits.splice(0),
      shouldFreezeSourceReveal: this.#shouldFreezeSourceReveal,
    });
    if (!rendered) this.#render();
  }

  #shouldFreezeSourceReveal = () => this.#touchSelection.isActive;

  #render() {
    renderEditorPresentation({
      editor: this.#editor, syntax: this.syntax, input: this.#input,
      projection: this.#projection, affordances: this.#affordances, carets: this.#carets,
      synchronizer: this.#inputSynchronizer, copyCode: (text) => copyCodeBlock(text, this.#clipboardHooks),
      shouldFreezeSourceReveal: this.#shouldFreezeSourceReveal,
    });
  }

  #clipboardHooks;

  #applyAttributes() {
    applyEditorAttributes(this, this.#input, this.#keyboardHelp, keyboardHelpText);
    this.#commandRail?.update();
  }

  #emitRequest(kind, payload) {
    dispatchEditorEvent(this, "continuity-request", {
      version: EVENT_VERSION,
      sequence: ++this.#requestSequence,
      kind,
      ...payload,
    });
  }

  #emitError(error) {
    dispatchEditorEvent(this, "continuity-error", { version: EVENT_VERSION, error });
  }

  #requireEditor() {
    return requireLiveEditor(this.#editor, this.#isDestroyed);
  }
}
