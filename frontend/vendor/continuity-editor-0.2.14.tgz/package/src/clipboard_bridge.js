// Clipboard access for editor-initiated actions.
//
// Split from the element because the browser will refuse these for reasons the
// editor cannot fix — an insecure context has no `navigator.clipboard` at all,
// and a read can be denied by permission policy. Every path therefore has a
// host fallback: the editor asks, and a host that has its own clipboard route
// can answer. Clipboard *events* (copy/cut/paste on the textarea) are a separate
// concern and stay in `input_events.js`.

import { writeClipboardText } from "./code_affordances.js";

/** Bind the clipboard fallbacks to one editor's textarea and event surface. */
export function createClipboardHooks({ input, emitRequest, emitError }) {
  return {
    emitRequest,
    emitError,
    refocus: () => input.focus({ preventScroll: true }),
    copySelection: () => {
      input.focus({ preventScroll: true });
      return input.selectionEnd > input.selectionStart && document.execCommand("copy");
    },
  };
}

/** Read clipboard text, delegating to the host when the browser refuses. */
export async function readClipboardText(hooks) {
  if (!navigator.clipboard?.readText) {
    hooks.emitRequest("pasteText", {});
    return null;
  }
  try {
    return await navigator.clipboard.readText();
  } catch (error) {
    hooks.emitRequest("pasteText", {});
    hooks.emitError(error);
    return null;
  }
}

/**
 * Write text, delegating to the host when the browser refuses.
 *
 * The editor's own textarea already holds the selection, so copying it in place
 * is tried before the detached-textarea fallback: that fallback has to steal
 * focus, and on a phone stealing focus mid-gesture is what makes the copy fail
 * silently. `execCommand` also needs the user gesture that is still on the
 * stack, so nothing here may await before reaching it.
 */
export async function copyText(text, hooks) {
  if (navigator.clipboard?.writeText) {
    try {
      await navigator.clipboard.writeText(text);
      return;
    } catch { /* insecure context or denied policy; fall through */ }
  }
  try {
    if (hooks.copySelection()) return;
    await writeClipboardText(text);
  } catch (error) {
    hooks.emitRequest("copyText", { text });
    hooks.emitError(error);
  }
}

/**
 * Copy a fenced code block. Unlike the selection actions this rethrows, because
 * the affordance that triggered it reports success or failure in its own label.
 */
export async function copyCodeBlock(text, hooks) {
  try {
    await writeClipboardText(text);
  } catch (error) {
    hooks.emitRequest("copyText", { text });
    hooks.emitError(error);
    throw error;
  } finally {
    hooks.refocus();
  }
}
