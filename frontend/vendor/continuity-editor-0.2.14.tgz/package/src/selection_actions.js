// Touch selection action bar.
//
// Taking the platform's long-press selection away also takes away the bubble it
// carried — copy, cut, paste, select all. On a phone that is the only way to
// reach the clipboard, so the editor has to supply it. The bar appears once a
// non-collapsed selection settles and the finger lifts, positioned clear of the
// selection rather than under it.

const CLEARANCE_PX = 10;

const ACTIONS = [
  { id: "copy", label: "Copy" },
  { id: "cut", label: "Cut" },
  { id: "paste", label: "Paste" },
  { id: "select-all", label: "Select all" },
];

/** Build the bar and return a controller the element drives. */
export function createSelectionActions(dom, hooks) {
  const bar = document.createElement("div");
  bar.className = "selection-actions";
  bar.setAttribute("role", "toolbar");
  bar.setAttribute("aria-label", "Selection actions");
  bar.hidden = true;
  for (const action of ACTIONS) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "selection-actions-button";
    button.dataset.selectionAction = action.id;
    button.textContent = action.label;
    // Capture the selected text on the way down. Tapping the button can move
    // focus and collapse the textarea's selection, so reading it later can find
    // nothing left to copy — which looks exactly like a dead button.
    let armed = null;
    button.addEventListener("pointerdown", (event) => {
      armed = hooks.captureSelection();
      // Preventing the default here suppresses the synthesized `click` on
      // touch, so only a mouse — where it stops the blur — gets it.
      if (event.pointerType === "mouse") event.preventDefault();
    });
    // `pointerup` and `click` both fire it; whichever arrives first disarms.
    const fire = () => {
      const captured = armed;
      armed = null;
      if (captured !== null) hooks.run(action.id, captured);
    };
    button.addEventListener("pointerup", fire);
    button.addEventListener("click", fire);
    bar.append(button);
  }
  dom.frame.append(bar);

  return {
    element: bar,
    hide() {
      if (!bar.hidden) bar.hidden = true;
    },
    /** Show the bar above the selection, or below it when there is no room. */
    update() {
      if (!hooks.isEnabled()) {
        bar.hidden = true;
        return;
      }
      const highlight = dom.carets.querySelector(".visual-selection");
      if (!highlight) {
        bar.hidden = true;
        return;
      }
      bar.hidden = false;
      const pasteButton = bar.querySelector('[data-selection-action="paste"]');
      if (pasteButton) pasteButton.hidden = !hooks.canPaste();
      positionBar(bar, dom.frame, highlight.getBoundingClientRect());
    },
  };
}

function positionBar(bar, frame, selectionBounds) {
  const frameBounds = frame.getBoundingClientRect();
  const barBounds = bar.getBoundingClientRect();
  const above = selectionBounds.top - frameBounds.top - barBounds.height - CLEARANCE_PX;
  const below = selectionBounds.bottom - frameBounds.top + CLEARANCE_PX;
  const top = above >= 0 ? above : below;
  const left = Math.max(
    CLEARANCE_PX,
    Math.min(
      selectionBounds.left - frameBounds.left,
      frameBounds.width - barBounds.width - CLEARANCE_PX,
    ),
  );
  bar.style.transform = `translate(${Math.round(left)}px, ${Math.round(top)}px)`;
}
