/** Build the semantic input, visual projection, and non-semantic overlay layers. */
export function buildEditorDom(host, styles) {
  const shadow = host.attachShadow({ mode: "open", delegatesFocus: true });
  const style = document.createElement("style");
  style.textContent = styles;
  const frame = document.createElement("div");
  frame.className = "frame";
  frame.setAttribute("part", "frame");
  const projection = document.createElement("div");
  projection.className = "projection";
  projection.setAttribute("part", "projection");
  projection.setAttribute("aria-hidden", "true");
  const affordances = document.createElement("div");
  affordances.className = "affordances";
  affordances.setAttribute("part", "affordances");
  const carets = document.createElement("div");
  carets.className = "secondary-carets";
  carets.setAttribute("aria-hidden", "true");
  const input = document.createElement("textarea");
  input.className = "input";
  input.setAttribute("part", "input");
  input.setAttribute("aria-multiline", "true");
  input.setAttribute("autocomplete", "off");
  input.setAttribute("autocapitalize", "off");
  input.setAttribute("aria-describedby", "continuity-keyboard-help");
  input.setAttribute("wrap", "soft");
  frame.append(projection, input, carets, affordances);
  const keyboardHelp = document.createElement("span");
  keyboardHelp.id = "continuity-keyboard-help";
  keyboardHelp.className = "keyboard-help";
  shadow.append(style, frame, keyboardHelp);
  return { affordances, carets, frame, input, keyboardHelp, projection };
}

/** Synchronize host attributes into the semantic textarea. */
export function applyEditorAttributes(host, input, keyboardHelp, helpText) {
  if (!input) {
    return;
  }
  input.readOnly = host.readOnly;
  input.setAttribute("aria-readonly", String(host.readOnly));
  input.setAttribute("aria-label", host.getAttribute("aria-label") || "Markdown editor");
  input.spellcheck = host.spellcheck;
  keyboardHelp.textContent = helpText(host.getAttribute("tab-behavior"), host.readOnly);
}
