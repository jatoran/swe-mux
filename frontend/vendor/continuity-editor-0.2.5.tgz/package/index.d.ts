export type Position = Readonly<{
  line: number;
  byteInLine: number;
}>;

export type SelectionKind = "caret" | "lineWise" | "blockWise";

export type Selection = Readonly<{
  anchor: Position;
  head: Position;
  kind: SelectionKind;
}>;

export type Range = Readonly<{ start: Position; end: Position }>;
export type ScrollState = Readonly<{ top: number; left: number }>;

export type Delta = Readonly<{
  at: number;
  removedBytes: number;
  insertedBytes: number;
}>;

export type AppliedEdit = Readonly<{
  at: number;
  removedBytes: number;
  insertedText: string;
  startLine: number;
  endLine: number;
  /** UTF-16 offsets populated by the JavaScript facade for DOM mirroring. */
  startUtf16: number;
  endUtf16: number;
}>;

export type Change = Readonly<{
  kind: "rawEdit" | "groupedEdit" | "selectionEdit" | "undo" | "redo";
  command: string;
  revisionBefore: number;
  revisionAfter: number;
  selectionsBefore: readonly Selection[];
  selectionsAfter: readonly Selection[];
  deltas: readonly Delta[];
  edits: readonly AppliedEdit[];
  checksumAfter: string;
}>;

export type Snapshot = Readonly<{
  text: string;
  revision: number;
  selections: readonly Selection[];
  isReadOnly: boolean;
}>;

export type Segment = Readonly<{
  kind: "visible" | "hidden" | "replace";
  startByte: number;
  endByte: number;
  replacement: string;
}>;

export type Span = Readonly<{
  kind: string;
  startByte: number;
  endByte: number;
}>;

export type DisplayLine = Readonly<{
  text: string;
  sourceToDisplay: readonly (readonly [number, number])[];
  displayToSource: readonly (readonly [number, number])[];
  segments: readonly Segment[];
}>;

export type Projection = Readonly<{
  blocks: readonly Span[];
  inlines: readonly Span[];
  lines: readonly DisplayLine[];
}>;

export type PresentationLine = Readonly<{
  text: string;
  sourceToDisplay: readonly [];
  displayToSource: readonly [];
  segments: readonly Segment[];
}>;

export type Presentation = Readonly<{
  blocks: readonly Span[];
  inlines: readonly Span[];
  lines: readonly PresentationLine[];
}>;

export type PresentationRange = Readonly<{
  startLine: number;
  endLine: number;
  lineCount: number;
  lineStarts: readonly number[];
  blocks: readonly Span[];
  inlines: readonly Span[];
  lines: readonly PresentationLine[];
}>;

export type WasmInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export function initialize(options?: Readonly<{ wasm?: WasmInput }>): Promise<void>;

export class ContinuityInitError extends Error {
  readonly code: "wasm-initialization-failed";
  readonly cause: unknown;
}

export class RevisionConflictError extends Error {
  readonly expectedRevision: number;
  readonly actualRevision: number;
}

export class Editor {
  constructor(initialValue?: string, initialRevision?: number);
  setSelections(selections: readonly Selection[]): void;
  insertText(text: string, timestampMs?: number): Change | null;
  deleteBackward(timestampMs?: number): Change | null;
  deleteForward(timestampMs?: number): Change | null;
  indent(timestampMs?: number): Change | null;
  outdent(timestampMs?: number): Change | null;
  executeCommand(command: string, timestampMs?: number): Change | null;
  undo(timestampMs?: number): Change | null;
  redo(timestampMs?: number): Change | null;
  redoAlternate(timestampMs?: number): Change | null;
  replaceValue(value: string, expectedRevision: number, timestampMs?: number): Change | null;
  snapshot(): Snapshot;
  projection(): Projection;
  presentation(): Presentation;
  presentationRange(startLine: number, endLine: number): PresentationRange;
  linearMemoryBytes(): number;
  destroy(): void;
}

export type ContinuityChangeDetail = Readonly<{
  version: 1;
  sequence: number;
  source: "insert" | "deleteBackward" | "deleteForward" | "indent" | "outdent" | "undo" | "redo" |
    "compositionCommit" | "browserReconcile" | "hostReplacement" | `command:${string}`;
  /** Stable persistence boundary: hosts persist only user-origin commits. */
  commitOrigin: "user" | "host";
  change: Change;
  snapshot: Snapshot;
}>;

export type ContinuityRequestDetail = Readonly<{
  version: 1;
  sequence: number;
}> & (
  | Readonly<{ kind: "openLink"; label: string; href: string }>
  | Readonly<{ kind: "contextMenu"; clientX: number; clientY: number }>
  | Readonly<{ kind: "copyText"; text: string }>
  | Readonly<{ kind: "filesDropped"; files: readonly File[] }>
);

export type ContinuityFrameDetail = Readonly<{
  version: 1;
  revision: number;
  inputStartedAt: number;
  /** Fast projection completion in the animation frame submitted for paint. */
  paintedAt: number;
  latencyMs: number;
}>;

export type ContinuityReadyDetail = Readonly<{
  version: 1;
  snapshot: Snapshot;
}>;

export type ContinuityErrorDetail = Readonly<{
  version: 1;
  error: unknown;
}>;

export type ContinuityShortcutSuppressedDetail = Readonly<{
  version: 1;
  chord: string;
  command: string;
  policy: ShortcutPolicy;
}>;

export type ShortcutPolicy = "browser-safe" | "editor-first" | "none";
export type ShortcutBindings = Readonly<Record<string, string | null>> |
  ReadonlyMap<string, string | null>;
export type ShortcutBinding = Readonly<{
  chord: string;
  command: string;
  isBrowserSafe: boolean;
}>;

export function listShortcutBindings(): readonly ShortcutBinding[];

export class ContinuityEditorElement extends HTMLElement {
  readonly ready: Promise<this>;
  value: string;
  initialRevision: number;
  readOnly: boolean;
  spellcheck: boolean;
  shortcutPolicy: ShortcutPolicy;
  shortcutBindings: ShortcutBindings;
  syntax: "markdown" | "plain";
  snapshot(): Snapshot;
  replaceValue(value: string, expectedRevision: number, timestampMs?: number): Change | null;
  executeCommand(command: string, timestampMs?: number): Change | null;
  setSelections(selections: readonly Selection[], options?: Readonly<{ reveal?: boolean }>): Snapshot;
  revealRange(range: Range, options?: Readonly<{ align?: "nearest" | "center" }>): void;
  getScrollState(): ScrollState;
  restoreScrollState(state: ScrollState): void;
  linearMemoryBytes(): number;
  focus(options?: FocusOptions): void;
  destroy(): void;
}

export class ContinuityRendererElement extends HTMLElement {
  readonly ready: Promise<this>;
  value: string;
  syntax: "markdown" | "plain";
  getScrollState(): ScrollState;
  restoreScrollState(state: ScrollState): void;
  linearMemoryBytes(): number;
  destroy(): void;
}

export function defineContinuityEditor(registry?: CustomElementRegistry): void;

declare global {
  interface HTMLElementTagNameMap {
    "continuity-editor": ContinuityEditorElement;
    "continuity-renderer": ContinuityRendererElement;
  }

  interface GlobalEventHandlersEventMap {
    "continuity-change": CustomEvent<ContinuityChangeDetail>;
    "continuity-request": CustomEvent<ContinuityRequestDetail>;
    "continuity-frame": CustomEvent<ContinuityFrameDetail>;
    "continuity-ready": CustomEvent<ContinuityReadyDetail>;
    "continuity-destroy": CustomEvent<Readonly<{ version: 1 }>>;
    "continuity-error": CustomEvent<ContinuityErrorDetail>;
    "continuity-shortcut-suppressed": CustomEvent<ContinuityShortcutSuppressedDetail>;
  }
}
