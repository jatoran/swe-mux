import {
  applyPrimaryPointerCapture,
  applyProjectedPointerSelection,
  handleUnmodifiedPointerClick,
} from "./pointer_gesture.js";
import { revealCodeAffordanceAt } from "./code_affordances.js";
import { findMarkdownLink } from "./projection.js";
import { addPointerCaret, addVerticalCaret } from "./multi_selection.js";
import { renderSelectionOverlays } from "./selection_overlays.js";
import { selectionFromInput } from "./coordinates.js";
import { inputSelectionKey } from "./input_sync.js";

// Pointer and projected-selection application for the editor element. These
// operate on a `ctx` bag the element builds once (stable DOM refs plus small
// closures over its private state), so the class body stays under the file cap
// while this file owns one responsibility: turning a physical pointer gesture
// into an engine + textarea + overlay selection.

/** Begin a projection-owned gesture; a fresh gesture drops any deferred tap. */
export function handlePointerDown(ctx, event) {
  if (!ctx.editor() || event.button !== 0) return;
  // A fresh gesture supersedes any tap still deferred behind composition.
  ctx.setPending(null);
  applyPrimaryPointerCapture(ctx.input, event);
  if (!event.ctrlKey && !event.metaKey) ctx.setCollapse(true);
  ctx.gesture.begin(event, ctx.projection, ctx.editor().snapshot().selections);
}

/** Reveal hovered code affordances and commit any mouse/pen drag selection. */
export function handlePointerMove(ctx, event) {
  revealCodeAffordanceAt(ctx.affordances, event.clientX, event.clientY);
  commitProjectedSelection(ctx, ctx.gesture.move(event, ctx.projection));
}

/** A scroll or platform gesture took the pointer; drop all tap/drag state. */
export function handlePointerCancel(ctx) {
  ctx.gesture.cancel();
  ctx.setCollapse(false);
  ctx.setPending(null);
}

/** Commit one projection-mapped range to the engine, textarea, and render. */
export function commitProjectedSelection(ctx, selection) {
  const selectionKey = applyProjectedPointerSelection(ctx.editor(), ctx.input, selection);
  if (selectionKey !== null) {
    ctx.setSelectionKey(selectionKey);
    ctx.schedule();
  }
}

/**
 * Replay a tap that landed during composition against the fresh snapshot. The
 * engine only matches the textarea after `compositionend` reconciles, so the
 * intended canonical position is retained until then and applied here.
 */
export function applyPendingProjectedSelection(ctx) {
  const pending = ctx.getPending();
  ctx.setPending(null);
  if (!pending || !ctx.editor()) return;
  ctx.setCollapse(false);
  commitProjectedSelection(ctx, pending);
}

/** Complete a primary click into a selection, checkbox toggle, or link open. */
export function completeProjectedPointerClick(ctx, event) {
  const gesture = ctx.gesture.complete(event);
  if (ctx.isComposing()) {
    // The engine still holds pre-composition text, so a projected selection
    // cannot be applied yet. Retain the intended canonical position and replay
    // it once compositionEnd reconciles. In the whole-frame fallback the
    // projection is not reliable, so prefer the native textarea caret.
    if (gesture.selection) {
      ctx.setPending(ctx.frame.classList.contains("composing-fallback")
        ? selectionFromInput(ctx.input.value, ctx.input)
        : gesture.selection);
    }
    return;
  }
  commitProjectedSelection(ctx, gesture.selection);
  if (handleUnmodifiedPointerClick(
    event, gesture, ctx.editor(), ctx.input,
    () => { ctx.sync(); ctx.schedule(); },
    () => ctx.executeCommand("markdown.toggle_checkbox"),
  )) {
    ctx.setCollapse(false);
    return;
  }
  const link = findMarkdownLink(ctx.input.value, ctx.input.selectionStart);
  if (link) {
    ctx.emitRequest("openLink", link);
  } else if (ctx.editor() && gesture.selectionsBeforePointer) {
    ctx.editor().setSelections(addPointerCaret(
      ctx.input.value,
      gesture.selectionsBeforePointer,
      ctx.input,
    ));
    ctx.sync();
    renderSelectionOverlays(ctx.carets, ctx.projection, ctx.editor().snapshot());
    ctx.schedule();
  }
}

/** Add or remove a vertical (column) caret above/below the primary caret. */
export function applyVerticalCaret(ctx, direction) {
  if (!ctx.editor()) return;
  ctx.editor().setSelections(addVerticalCaret(ctx.editor().snapshot(), direction, ctx.input));
  ctx.sync();
  renderSelectionOverlays(ctx.carets, ctx.projection, ctx.editor().snapshot());
  ctx.schedule();
}

/** Collapse every secondary selection back to the single textarea caret. */
export function clearSecondarySelections(ctx) {
  if (!ctx.editor()) return;
  ctx.editor().setSelections([selectionFromInput(ctx.input.value, ctx.input)]);
  ctx.setSelectionKey(inputSelectionKey(ctx.input));
  ctx.schedule();
}
