export const EDITOR_STYLES = `
:host {
  --continuity-background: #111318;
  --continuity-foreground: #e7e9ee;
  --continuity-muted: #8d96a8;
  --continuity-accent: #7aa2f7;
  --continuity-selection: rgb(68 110 180 / 42%);
  --continuity-border: #2b303b;
  display: block;
  contain: layout paint style;
  min-block-size: 12rem;
  color-scheme: dark;
}
:host([theme="light"]) {
  --continuity-background: #fbfbfc;
  --continuity-foreground: #20232a;
  --continuity-muted: #687083;
  --continuity-accent: #315fba;
  --continuity-selection: rgb(70 120 210 / 30%);
  --continuity-border: #d9dce3;
  color-scheme: light;
}
@media (prefers-color-scheme: light) {
  :host(:not([theme="dark"])) {
    --continuity-background: #fbfbfc;
    --continuity-foreground: #20232a;
    --continuity-muted: #687083;
    --continuity-accent: #315fba;
    --continuity-selection: rgb(70 120 210 / 30%);
    --continuity-border: #d9dce3;
    color-scheme: light;
  }
}
.frame {
  position: relative;
  overflow: hidden;
  box-sizing: border-box;
  width: 100%;
  height: 100%;
  min-height: inherit;
  border: 1px solid var(--continuity-border);
  border-radius: 8px;
  background: var(--continuity-background);
  color: var(--continuity-foreground);
}
.projection,
.input {
  box-sizing: border-box;
  margin: 0;
  padding: 1rem 1.1rem;
  width: 100%;
  min-height: 100%;
  font-family: var(--continuity-font-family, ui-monospace, "Cascadia Mono", Consolas, monospace);
  font-size: var(--continuity-font-size, 16px);
  font-style: normal;
  font-weight: 400;
  line-height: var(--continuity-line-height, 1.55);
  tab-size: 4;
  white-space: pre-wrap;
  overflow-wrap: anywhere;
}
.projection {
  position: absolute;
  inset: 0;
  width: calc(100% - 14px);
  height: max-content;
  min-height: 100%;
  pointer-events: none;
  transform-origin: top left;
  will-change: transform;
}
.affordances {
  position: absolute;
  inset: 0;
  width: calc(100% - 14px);
  height: max-content;
  min-height: 100%;
  pointer-events: none;
  transform-origin: top left;
  will-change: transform;
  z-index: 3;
}
.input {
  position: absolute;
  inset: 0;
  resize: none;
  border: 0;
  outline: 0;
  background: transparent;
  color: transparent;
  caret-color: transparent;
  -webkit-text-fill-color: transparent;
  overflow: auto;
  z-index: 1;
}
.input::selection {
  background: transparent;
  color: transparent;
}
.frame:focus-within {
  box-shadow: inset 0 0 0 1px var(--continuity-accent);
}
.keyboard-help {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border: 0;
}
.composition-run {
  text-decoration: underline;
  text-decoration-skip-ink: none;
}
.frame.composing-fallback .projection { opacity: 0; }
.frame.composing-fallback .input {
  color: var(--continuity-foreground);
  caret-color: var(--continuity-accent);
  -webkit-text-fill-color: var(--continuity-foreground);
}
.frame.composing-fallback .input::selection { background: var(--continuity-selection); }
.frame.composing-fallback .visual-caret,
.frame.composing-fallback .visual-selection { display: none; }
.line {
  box-sizing: border-box;
  min-height: var(--continuity-line-height, 1.55em);
  line-height: var(--continuity-line-height, 1.55em);
  padding-inline-start: var(--continuity-wrap-indent, 0ch);
  text-indent: calc(-1 * var(--continuity-wrap-indent, 0ch));
}
.line[data-break-unbroken="true"] { word-break: break-all; }
.block-heading-1, .block-heading-2, .block-heading-3,
.block-heading-4, .block-heading-5, .block-heading-6,
.block-setextHeading {
  color: var(--continuity-foreground);
  font-weight: 750;
}
.block-heading-1:not([data-source-visible="true"]) { font-size: 1.45em; }
.block-heading-2:not([data-source-visible="true"]),
.block-setextHeading:not([data-source-visible="true"]) { font-size: 1.32em; }
.block-heading-3:not([data-source-visible="true"]) { font-size: 1.22em; }
.block-heading-4:not([data-source-visible="true"]) { font-size: 1.14em; }
.block-heading-5:not([data-source-visible="true"]) { font-size: 1.08em; }
.block-heading-6:not([data-source-visible="true"]) { font-size: 1.03em; }
.block-blockQuote { border-inline-start: 3px solid var(--continuity-border); padding-inline-start: .75rem; color: var(--continuity-muted); }
.block-fencedCodeBlock, .block-indentedCodeBlock { background: color-mix(in srgb, var(--continuity-foreground) 6%, transparent); }
.inline-strong { font-weight: 750; }
.inline-emphasis { font-style: italic; }
.inline-strikethrough { text-decoration: line-through; }
.inline-code { color: var(--continuity-accent); }
.inline-checkbox { color: var(--continuity-accent); }
.inline-link { color: var(--continuity-accent); text-decoration: underline; }
.secondary-carets {
  position: absolute;
  inset: 0;
  pointer-events: none;
  z-index: 2;
}
.visual-caret {
  position: absolute;
  inset: 0 auto auto 0;
  width: 2px;
  background: var(--continuity-accent);
}
.visual-selection {
  position: absolute;
  inset: 0 auto auto 0;
  border-radius: 1px;
  background: var(--continuity-selection);
}
.primary-caret { animation: continuity-caret-blink 1s step-end infinite; }
.frame:not(:focus-within) .primary-caret { display: none; }
@keyframes continuity-caret-blink { 50% { opacity: 0; } }
.code-copy {
  position: absolute;
  box-sizing: border-box;
  min-width: 56px;
  padding: 4px 8px;
  border: 1px solid var(--continuity-border);
  border-radius: 5px;
  opacity: 0;
  pointer-events: none;
  background: color-mix(in srgb, var(--continuity-background) 88%, var(--continuity-foreground));
  color: var(--continuity-foreground);
  font: 600 12px/1.3 system-ui, sans-serif;
  cursor: pointer;
}
.code-copy.visible {
  opacity: 1;
  pointer-events: auto;
}
@media (pointer: coarse) {
  .code-copy { min-width: 64px; min-height: 40px; }
}
.code-copy.copied {
  border-color: var(--continuity-accent);
  background: var(--continuity-accent);
  color: var(--continuity-background);
}
.code-copy-block { right: 23px; }
.code-copy-inline { transform: translateY(-2px); }
/* Rail chrome is sized in px (host-tunable via custom properties): rem would
   resolve against the embedding page's root font-size, which dense hosts set
   as low as 11px — shrinking touch targets far below the 44-48px guideline. */
.command-rail {
  position: absolute;
  inset: auto 0 0 0;
  display: flex;
  align-items: center;
  gap: 3px;
  box-sizing: border-box;
  height: var(--continuity-rail-height, 56px);
  padding: 4px 6px;
  border-top: 1px solid var(--continuity-border);
  background: var(--continuity-background);
  z-index: 4;
}
.command-rail[hidden] { display: none; }
.frame.command-rail-active .input { bottom: var(--continuity-rail-height, 56px); }
.command-rail-buttons {
  display: flex;
  flex: 1;
  gap: 3px;
  overflow-x: auto;
  scrollbar-width: none;
}
.command-rail-buttons::-webkit-scrollbar { display: none; }
.command-rail-button {
  flex: 0 0 auto;
  box-sizing: border-box;
  min-width: var(--continuity-rail-button-size, 48px);
  height: var(--continuity-rail-button-size, 48px);
  padding: 0 6px;
  border: 0;
  border-radius: 6px;
  background: transparent;
  color: var(--continuity-foreground);
  font: 600 var(--continuity-rail-font-size, 17px)/1 system-ui, sans-serif;
  cursor: pointer;
}
.command-rail-button:active {
  background: color-mix(in srgb, var(--continuity-foreground) 14%, transparent);
}
.command-rail-glyph-bold { font-weight: 800; }
.command-rail-glyph-italic { font-style: italic; }
.command-rail-glyph-strikethrough { text-decoration: line-through; }
.command-rail-glyph-inline-code {
  font-family: inherit;
  font-size: 13px;
  color: var(--continuity-accent);
}
.command-rail-settings {
  position: absolute;
  right: 5px;
  bottom: calc(var(--continuity-rail-height, 56px) + 4px);
  z-index: 5;
  box-sizing: border-box;
  width: min(340px, calc(100% - 10px));
  max-height: min(60%, 380px);
  overflow-y: auto;
  padding: 6px;
  border: 1px solid var(--continuity-border);
  border-radius: 8px;
  background: var(--continuity-background);
  color: var(--continuity-foreground);
  font: 500 14px/1.35 system-ui, sans-serif;
}
.command-rail-settings-row {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 2px 0;
}
.command-rail-settings-name { flex: 1; }
.command-rail-settings-toggle,
.command-rail-settings-move,
.command-rail-settings-action {
  box-sizing: border-box;
  min-width: 44px;
  height: 44px;
  border: 1px solid var(--continuity-border);
  border-radius: 5px;
  background: transparent;
  color: var(--continuity-foreground);
  font: 600 14px/1 system-ui, sans-serif;
  cursor: pointer;
}
.command-rail-settings-toggle[aria-pressed="true"] {
  border-color: var(--continuity-accent);
  color: var(--continuity-accent);
}
.command-rail-settings-move:disabled { opacity: .35; cursor: default; }
.command-rail-settings-footer {
  display: flex;
  justify-content: flex-end;
  padding-top: 5px;
}
.command-rail-settings-action { min-width: 64px; }
:host([readonly]) .input { cursor: default; }
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after { scroll-behavior: auto !important; transition-duration: 0s !important; }
  .primary-caret { animation: none; }
}
`;
