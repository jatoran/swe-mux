import { hasCoarsePointer } from "./code_affordances.js";
import { toggleCommandRailSettings } from "./command_rail_settings.js";

/** Every quick action the rail can host, in default order. */
export const COMMAND_RAIL_CATALOG = [
  { id: "undo", command: "editor.undo", glyph: "↺", label: "Undo" },
  { id: "redo", command: "editor.redo", glyph: "↻", label: "Redo" },
  { id: "indent", command: "editor.indent", glyph: "⇥", label: "Indent" },
  { id: "outdent", command: "editor.outdent", glyph: "⇤", label: "Outdent" },
  { id: "bullet", command: "markdown.toggle_bullet", glyph: "•", label: "Toggle bullet" },
  { id: "checkbox", command: "markdown.toggle_task", glyph: "☑", label: "Toggle task" },
  { id: "numbered", command: "markdown.toggle_numbered", glyph: "1.", label: "Toggle numbered list" },
  { id: "bold", command: "markdown.toggle_bold", glyph: "B", label: "Toggle bold" },
  { id: "italic", command: "markdown.toggle_italic", glyph: "I", label: "Toggle italic" },
  { id: "strikethrough", command: "markdown.toggle_strikethrough", glyph: "S", label: "Toggle strikethrough" },
  { id: "inline-code", command: "markdown.toggle_inline_code", glyph: "</>", label: "Toggle inline code" },
  { id: "heading", command: "markdown.cycle_heading_up", glyph: "H", label: "Cycle heading" },
  { id: "quote", command: "markdown.wrap_in_blockquote", glyph: "❝", label: "Wrap in blockquote" },
  { id: "link", command: "markdown.insert_link", glyph: "\u{1F517}", label: "Insert link" },
];

const DEFAULT_DISABLED = new Set(["numbered", "strikethrough", "quote", "link"]);
const STORAGE_KEY = "continuity-editor.command-rail";

/**
 * Attach the bottom quick-action rail to the editor frame. The rail shows on
 * touch-primary devices by default (`command-rail="auto"`), can be forced with
 * `command-rail="on|off"`, and hides while the editor is read-only. Buttons
 * cancel `pointerdown` so the semantic textarea keeps focus and the virtual
 * keyboard stays open. The gear button opens a settings panel that toggles
 * and reorders buttons; the arrangement persists in `localStorage` under
 * `continuity-editor.command-rail`.
 */
export function attachCommandRail(host, dom, execute, signal) {
  const rail = document.createElement("div");
  rail.className = "command-rail";
  rail.setAttribute("part", "command-rail");
  rail.setAttribute("role", "toolbar");
  rail.setAttribute("aria-label", "Editor quick actions");
  rail.hidden = true;
  const strip = document.createElement("div");
  strip.className = "command-rail-buttons";
  const settingsButton = document.createElement("button");
  settingsButton.type = "button";
  settingsButton.className = "command-rail-button command-rail-settings-button";
  settingsButton.textContent = "⚙";
  settingsButton.setAttribute("aria-label", "Command rail settings");
  settingsButton.setAttribute("aria-expanded", "false");
  settingsButton.addEventListener("pointerdown", (event) => event.preventDefault());
  rail.append(strip, settingsButton);
  dom.frame.append(rail);

  const state = loadRailConfiguration();
  const renderStrip = () => renderRailButtons(strip, state, execute, signal);
  const applyChange = () => {
    saveRailConfiguration(state);
    renderStrip();
  };
  settingsButton.addEventListener("click", () => {
    const isOpen = toggleCommandRailSettings(dom.frame, state, applyChange);
    settingsButton.setAttribute("aria-expanded", String(isOpen));
  }, { signal });

  const update = () => {
    const isActive = resolveRailActive(host) && !host.readOnly;
    rail.hidden = !isActive;
    dom.frame.classList.toggle("command-rail-active", isActive);
    if (!isActive) {
      toggleCommandRailSettings(dom.frame, state, applyChange, false);
      settingsButton.setAttribute("aria-expanded", "false");
    }
  };
  const pointerQuery = globalThis.matchMedia?.("(pointer: coarse)");
  pointerQuery?.addEventListener?.("change", update, { signal });
  renderStrip();
  update();
  return { update };
}

function resolveRailActive(host) {
  const mode = host.getAttribute("command-rail");
  if (mode === "on") return true;
  if (mode === "off") return false;
  return hasCoarsePointer();
}

function renderRailButtons(strip, state, execute, signal) {
  const fragment = document.createDocumentFragment();
  for (const entry of state.order) {
    if (state.disabled.has(entry.id)) continue;
    const button = document.createElement("button");
    button.type = "button";
    button.className = "command-rail-button";
    button.dataset.railAction = entry.id;
    button.setAttribute("aria-label", entry.label);
    const glyph = document.createElement("span");
    glyph.className = `command-rail-glyph command-rail-glyph-${entry.id}`;
    glyph.textContent = entry.glyph;
    button.append(glyph);
    // Keep textarea focus so the virtual keyboard never dismisses mid-action.
    button.addEventListener("pointerdown", (event) => event.preventDefault());
    button.addEventListener("click", () => execute(entry.command), { signal });
    fragment.append(button);
  }
  strip.replaceChildren(fragment);
}

/** Load the persisted rail arrangement, normalized against the catalog. */
export function loadRailConfiguration(storage = defaultStorage()) {
  let stored = null;
  try {
    stored = JSON.parse(storage?.getItem(STORAGE_KEY) ?? "null");
  } catch {
    stored = null;
  }
  const storedOrder = Array.isArray(stored?.order) ? stored.order : [];
  const storedDisabled = Array.isArray(stored?.disabled) ? stored.disabled : null;
  const byId = new Map(COMMAND_RAIL_CATALOG.map((entry) => [entry.id, entry]));
  const order = storedOrder
    .map((id) => byId.get(id))
    .filter(Boolean);
  for (const entry of COMMAND_RAIL_CATALOG) {
    if (!order.includes(entry)) order.push(entry);
  }
  const known = new Set(byId.keys());
  const disabled = storedDisabled === null
    ? new Set(DEFAULT_DISABLED)
    : new Set(storedDisabled.filter((id) => known.has(id)));
  return { order, disabled };
}

/** Persist the rail arrangement; storage rejection is non-fatal. */
export function saveRailConfiguration(state, storage = defaultStorage()) {
  try {
    storage?.setItem(STORAGE_KEY, JSON.stringify({
      order: state.order.map((entry) => entry.id),
      disabled: [...state.disabled],
    }));
  } catch {
    // Blocked storage (private mode, embedder policy) keeps a session-local rail.
  }
}

/** Restore the default arrangement in place. */
export function resetRailConfiguration(state) {
  state.order.splice(0, state.order.length, ...COMMAND_RAIL_CATALOG);
  state.disabled.clear();
  for (const id of DEFAULT_DISABLED) state.disabled.add(id);
}

function defaultStorage() {
  try {
    return globalThis.localStorage;
  } catch {
    return null;
  }
}
